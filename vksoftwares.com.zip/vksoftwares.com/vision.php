<?php include 'header_2.php'; ?>
<div id="Content">
	<div class="content_wrapper clearfix">
		<div class="sections_group">
			<div class="entry-content" itemprop="mainContentOfPage">
				<div class="section the_content has_content">
					<div class="section_wrapper">
						<div class="the_content_wrapper">
							<p><strong>Vision:</strong></p>
							<p>&nbsp;</p>
							<table id="myTable" style="margin-left:10px;margin-top:20px;" border="1">
								<thead>
									<tr></tr>
								</thead>
								<tbody>
									<tr>
										<p>VK Softwares was started with a vision to become a programmers and customers heaven where each programmer is given equal opportunity to explore his skills and learn something new each day. We at VK Softwares always believed that Knowledge is Power. We always want to keep up with the technology upgrades and changes.</p>
										<p>We work for our customers with a motive to provide them state of the art services with best developers of the industry. We always want to meet the deadlines mutually agreed upon</p>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>

			<br />
			<br />
			<br />
			<br />
			<br />
			<br />
			<br />
			<br />
			<br />
			<br />
			<br />
			<br />
		</div>
	</div>
</div>
<?php include 'footer_2.php'; ?>