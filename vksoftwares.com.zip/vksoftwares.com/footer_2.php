			<footer id="Footer" class="clearfix">
				<div class="footer_copy">
					<div class="container">
						<div class="column one">
							<a id="back_to_top" class="button button_left button_js " href="#"><span class="button_icon"><i class="icon-up-open-big"></i></span></a>
							<!-- Copyrights -->
							<div class="copyright">
								© <?php echo date("Y"); ?>  VKSoftwares. All Rights Reserved. <a target="_blank" rel="nofollow" href="index.php">VKSoftwares</a>
							</div>                						
						</div>
					</div>
				</div>
			</footer>
		</div>
		
		<script type='text/javascript' src='js/js/jquery/jqueryc1d8c1d8.js?ver=1.11.3'></script>
        <script type='text/javascript' src='js/js/jquery/jquery-migrate.min15761576.js?ver=1.2.1'></script>  
		<script type='text/javascript' src='css/plugins/contact-form-7/includes/js/jquery.form.mind03dd03d.js?ver=3.51.0-2014.06.20'></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
		<script type='text/javascript' src='css/themes/betheme/js/scripts2c4c2c4c.js?ver=10.9'></script>
		<script type='text/javascript' src='css/themes/betheme/js/menu2c4c2c4c.js?ver=10.9'></script>		
		<script src="js/jquery.validate.js"></script>		
	</body>
</html>


<script>
var $grid = new Isotope('.grid', {
	itemSelector: '.box',
	layoutMode: 'masonry',
});

</script>