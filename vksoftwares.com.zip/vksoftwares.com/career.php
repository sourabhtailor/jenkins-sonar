<?php include 'header_2.php'; ?>
<div id="Content">
    <div class="content_wrapper clearfix">
        <div class="sections_group">		
            <div class="entry-content" itemprop="mainContentOfPage">
                <div class="section the_content has_content">
					<div class="section_wrapper">
						<div class="the_content_wrapper"><p><br/><strong style="font-size:25px;">Careers:</strong></p><br/>
                            <p style="font-size:20px;"><strong>VK Softwares</strong> is looking for :</p>
							<br/> 
                            <ul> 
                                <table id="myTable"  style="margin-left:10px;margin-top:20px;" border="1"> 
                                    <thead> 
                                        <tr></tr>
                                    </thead>
									<tbody style="font-size:20px;">
										<tr>
											<li>PHP Developers</li>
											<li>JAVA Developers</li>
											<li>Graphic Designers</li>
											<li>Android Developers</li>
											<li>iOS Developers</li>
											<li>.NET Developers</li>
											<li>Flash Designers / Developers</li>
										</tr>
                                    </tbody>
								</table>
							</ul>
							<br/><br/>                           
                        </div>
                    </div>
                </div>			
            </div>
        </div>
    </div>
</div>		
<?php include 'footer_2.php'; ?>