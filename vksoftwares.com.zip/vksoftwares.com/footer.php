<footer id="Footer" class="clearfix">
    <div class="footer_copy">
        <div class="container">
            <div class="column one">
                <a id="back_to_top" class="button button_left button_js " href="#"><span class="button_icon"><i class="icon-up-open-big"></i></span></a>
                <!-- Copyrights -->
                <div class="copyright">
                    © <?php echo date("Y"); ?>  VKSoftwares. All Rights Reserved. <a target="_blank" rel="nofollow" href="index.php">VKSoftwares</a>
                </div>                						
            </div>
        </div>
    </div>
</footer>